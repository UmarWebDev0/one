import framesJson from '../hero-frames.json';

export interface HeroFrame {
  index: number;
  page: string;
  directUrl: string;
  localUrl: string;
  jpgFallbackUrl: string;
}

const base = (import.meta.env.BASE_URL || '/').replace(/\/$/, '');

export const HERO_FRAMES: HeroFrame[] = (framesJson as { index: number; page: string; directUrl: string }[]).map(f => {
  const num = String(f.index).padStart(3, '0');
  return {
    ...f,
    localUrl: `${base}/frames/frame-${num}.webp`,
    jpgFallbackUrl: `${base}/frames/frame-${num}.jpg`,
  };
});

export const TOTAL_FRAMES = HERO_FRAMES.length;

