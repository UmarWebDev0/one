export const getAssetUrl = (path: string): string => {
  const base = (import.meta.env.BASE_URL || '/').replace(/\/$/, '');
  const cleanPath = path.startsWith('/') ? path : `/${path}`;
  return `${base}${cleanPath}`;
};

export interface Product {
  id: string;
  name: string;
  style: 'Chronograph' | 'Skeleton' | 'Gold' | 'Ceramic' | 'Sport' | 'Classic';
  collection?: string;
  category: string;
  reference: string;
  year?: string;
  price: number;
  material: string;
  caseSize: string;
  calibre: string;
  powerReserve: string;
  waterResistance: string;
  strap: string;
  description: string;
  features: string[];
  inStock: boolean;
  image: string;
  hoverImage: string;
  badge?: string;
}

export const PRODUCTS: Product[] = [
  {
    id: 'sovereign-chronograph-gold-steel',
    name: 'Sovereign Two-Tone Chronograph 41',
    style: 'Chronograph',
    category: 'Chronograph & Precious Metal',
    reference: 'REF. 116503-SOV',
    year: '2026',
    price: 34800,
    material: '18K Yellow Gold & Hand-Brushed Oystersteel',
    caseSize: '41 mm',
    calibre: 'Calibre V-4130 Manufacture Column-Wheel Chronograph',
    powerReserve: '72 Hours',
    waterResistance: '100 m / 10 ATM',
    strap: 'Solid 18K Yellow Gold & Oystersteel Bracelet with Concealed Clasp',
    description: 'The signature estate salon masterpiece. Cast in noble 18K yellow gold and cold-forged stainless steel, featuring an immaculate white lacquer tri-compax dial and high-frequency chronograph escapement.',
    features: [
      'Column-wheel vertical clutch chronograph movement',
      'Solid 18K yellow gold engraved tachymeter bezel',
      'Tri-compax gold-rimmed sub-dials with snailed finish',
      'Anti-reflective synthetic sapphire crystal with double AR coating'
    ],
    inStock: true,
    image: getAssetUrl('/watches/watch-1.webp'),
    hoverImage: getAssetUrl('/watches/watch-8.webp'),
    badge: 'Estate Salon Feature'
  },
  {
    id: 'monolith-skeleton-tourbillon',
    name: 'Monolith Flying Tourbillon Titanium',
    style: 'Skeleton',
    category: 'Haute Horlogerie Skeleton',
    reference: 'REF. 904.TX.0170.RX',
    year: '2026',
    price: 42500,
    material: 'Grade 5 Satin-Finished Aerospace Titanium',
    caseSize: '44 mm',
    calibre: 'Manufacture V-800 Skeleton Tourbillon',
    powerReserve: '115 Hours',
    waterResistance: '50 m / 5 ATM',
    strap: 'Black Structured Vulcanised Rubber with Titanium Deployant Buckle',
    description: 'An architectural expression of avant-garde watchmaking. A flying 60-second tourbillon suspended between micro-blasted titanium bridges, revealing every gear and lever in three-dimensional depth.',
    features: [
      'Flying 60-second tourbillon cage with titanium balance',
      'Micro-blasted Grade 5 titanium openworked chassis',
      'One-Click patented strap interchangeability system',
      'Twin continuous-discharge barrels delivering 115h reserve'
    ],
    inStock: true,
    image: getAssetUrl('/watches/watch-2.webp'),
    hoverImage: getAssetUrl('/watches/watch-5.webp'),
    badge: 'Limited Edition (100 Pcs)'
  },
  {
    id: 'aurelia-king-gold-chrono',
    name: 'Aurelia Royal King Gold Chrono',
    style: 'Gold',
    category: 'Precious Metals & Complications',
    reference: 'REF. 521.OX.1181.LR',
    year: '2025',
    price: 51200,
    material: '18K Satin-Brushed King Rose Gold (Platinum Enriched)',
    caseSize: '45 mm',
    calibre: 'Calibre V-1280 Self-Winding Automatic Chronograph',
    powerReserve: '72 Hours',
    waterResistance: '100 m / 10 ATM',
    strap: 'Black Alligator Leather Inlaid into Natural Vulcanised Rubber',
    description: 'Cast in an exclusive proprietary 18K gold alloy enriched with platinum, preserving its fiery rose-gold radiance forever. Hand-bevelled satin finishes with mirror-polished bevels and sapphire dial.',
    features: [
      'Proprietary 18K King Gold alloy impervious to atmospheric oxidation',
      'Smoked sapphire dial with applied 18K gold indices',
      'Alligator leather fused seamlessly to hypoallergenic rubber core',
      'Exhibition sapphire crystal caseback with skeletonised rotor'
    ],
    inStock: true,
    image: getAssetUrl('/watches/watch-3.webp'),
    hoverImage: getAssetUrl('/watches/watch-1.webp'),
    badge: 'Masterwork'
  },
  {
    id: 'obsidian-chronograph-all-black',
    name: 'Obsidian Chronograph All-Black',
    style: 'Ceramic',
    category: 'High-Tech Matte Ceramic',
    reference: 'REF. 411.CX.1114.RX',
    year: '2026',
    price: 26800,
    material: 'Micro-Blasted High-Tech Black Zirconium Ceramic',
    caseSize: '42 mm',
    calibre: 'Calibre V-1280 Flyback Automatic',
    powerReserve: '72 Hours',
    waterResistance: '100 m / 10 ATM',
    strap: 'Ribbed Matte Black Rubber with Black PVD Titanium Buckle',
    description: 'Stealth horology designed to absorb visible light. The column-wheel flyback mechanism is visible directly through the openworked dial, housed in a scratchproof ceramic monobloc case.',
    features: [
      'Diamond-hard zirconium oxide scratchproof ceramic case',
      'Integrated column-wheel flyback chronograph mechanism',
      'Matte black skeleton hands with anthracite luminescent fill',
      'Tungsten oscillating rotor visible through tinted sapphire back'
    ],
    inStock: true,
    image: getAssetUrl('/watches/watch-4.webp'),
    hoverImage: getAssetUrl('/watches/watch-7.webp'),
    badge: 'Stealth Series'
  },
  {
    id: 'spectra-sapphire-pure',
    name: 'Spectra Monolithic Sapphire Crystal',
    style: 'Skeleton',
    category: 'Pure Corundum Glass Horology',
    reference: 'REF. 906.JX.0120.RT',
    year: '2025',
    price: 88000,
    material: 'Polished Monocrystalline Synthetic Sapphire Crystal',
    caseSize: '42 mm',
    calibre: 'Manufacture V-605 Skeleton Tourbillon',
    powerReserve: '120 Hours',
    waterResistance: '30 m / 3 ATM',
    strap: 'Transparent Structured Rubber with Titanium Deployant',
    description: 'Milled from a single monolithic block of synthetic corundum sapphire second only to diamond in hardness (9 on Mohs scale). Completely transparent from all 360 degrees of view.',
    features: [
      'Entire case sculpted from pure synthetic sapphire block',
      'Tourbillon escapement appears to levitate inside optical glass',
      'Hardness 9 on Mohs scale — impervious to everyday abrasion',
      'Numbered allocation strictly limited to 30 specimens worldwide'
    ],
    inStock: false,
    image: getAssetUrl('/watches/watch-5.webp'),
    hoverImage: getAssetUrl('/watches/watch-2.webp'),
    badge: 'Private Allocation'
  },
  {
    id: 'aero-forged-carbon-sprint',
    name: 'Vapour Aerofusion Forged Carbon',
    style: 'Sport',
    category: 'High-Tech Composites',
    reference: 'REF. 703.QX.1123.NR',
    year: '2026',
    price: 31400,
    material: 'Compressed Forged Carbon Fiber & Grade 5 Titanium',
    caseSize: '43 mm',
    calibre: 'Calibre V-1155 Skeletonised Automatic',
    powerReserve: '50 Hours',
    waterResistance: '50 m / 5 ATM',
    strap: 'High-Tenacity Cordura Fabric with Titanium Deployant',
    description: 'Forged under 300 atmospheres of pressure. Every carbon bezel possesses a unique, unrepeatable marble-like grain pattern while weighing an astonishing 78 grams total.',
    features: [
      'Ultra-dense forged carbon composite with titanium chassis',
      'Titanium H-screws with hand-finished chamfered edges',
      'Featherweight 78 grams total weight for athletic comfort',
      'Double glare-proofed sapphire crystal with anti-fog treat'
    ],
    inStock: true,
    image: getAssetUrl('/watches/watch-6.webp'),
    hoverImage: getAssetUrl('/watches/watch-7.webp'),
    badge: 'Avant-Garde'
  },
  {
    id: 'oceanic-diver-titanium-300m',
    name: 'Abyssal Diver 300M Titanium',
    style: 'Sport',
    category: 'Professional Aquatic Horology',
    reference: 'REF. 731.NX.1190.RX',
    year: '2025',
    price: 21500,
    material: 'Brushed Grade 5 Titanium & Ceramic Bezel',
    caseSize: '43 mm',
    calibre: 'Calibre V-1400 Automatic Professional Diver',
    powerReserve: '70 Hours',
    waterResistance: '300 m / 30 ATM',
    strap: 'High-Pressure Ribbed Rubber Strap with Extension Buckle',
    description: 'Engineered for oceanic abysses. Helium escape valve, unidirectional 60-minute ceramic rotating bezel, and ultra-high luminescence markers legible in deep-water darkness.',
    features: [
      'Integrated automatic helium decompression valve at 9 o clock',
      'Unidirectional ceramic rotating bezel with 120 clicks',
      'Super-LumiNova BGW9 blue emission markers',
      'Pressure tested to 30 atmospheres (300 meters)'
    ],
    inStock: true,
    image: getAssetUrl('/watches/watch-7.webp'),
    hoverImage: getAssetUrl('/watches/watch-4.webp'),
    badge: 'Professional 300M'
  },
  {
    id: 'heritage-calatrava-classic-rose',
    name: 'Atelier Heritage Ultra-Thin Rose',
    style: 'Classic',
    category: 'Classic Haute Horlogerie',
    reference: 'REF. 511.OX.2610.LR',
    year: '2026',
    price: 28900,
    material: '18K King Rose Gold with Mirror Polish',
    caseSize: '40 mm',
    calibre: 'Manufacture V-1110 Ultra-Thin Hand-Wound (2.9mm)',
    powerReserve: '90 Hours',
    waterResistance: '30 m / 3 ATM',
    strap: 'Hand-Stitched Matte Black Alligator Leather Strap',
    description: 'A tribute to classical Swiss watchmaking proportions. An ultra-slender 7.2mm profile, grand feu white enamel dial, and hand-bevelled Geneva striping visible through the sapphire caseback.',
    features: [
      'Ultra-thin 2.9mm manufacture hand-wound movement',
      'Grand Feu enamel dial fired at 800°C for eternal purity',
      'Leaf-shaped 18K rose gold hands with mirror polish',
      'Geneva Seal certified chronometric precision'
    ],
    inStock: true,
    image: getAssetUrl('/watches/watch-8.webp'),
    hoverImage: getAssetUrl('/watches/watch-3.webp'),
    badge: 'Classical Grand Feu'
  }
];

export interface Boutique {
  city: string;
  address: string;
  country: string;
  phone: string;
  email: string;
  hours: string;
  featuredDirector: string;
}

export const BOUTIQUES: Boutique[] = [
  {
    city: 'Geneva Atelier Flagship',
    address: '40 Rue du Rhône',
    country: 'Switzerland',
    phone: '+92 3412683864',
    email: 'geneve@vauban-horlogerie.ch',
    hours: 'Mon – Sat: 10:00 – 18:30 (Private Appointments Available)',
    featuredDirector: 'Marc-Antoine de Vauban, Master Horologist'
  },
  {
    city: 'New York Madison',
    address: '743 Madison Avenue',
    country: 'United States',
    phone: '+92 3412683864',
    email: 'newyork@vauban-horlogerie.com',
    hours: 'Mon – Sat: 10:00 – 19:00 · Sun: 12:00 – 17:00',
    featuredDirector: 'Elena Vance, Client Relations Director'
  },
  {
    city: 'Tokyo Ginza',
    address: '6-10-1 Ginza, Chuo-ku',
    country: 'Japan',
    phone: '+92 3412683864',
    email: 'tokyo@vauban-horlogerie.jp',
    hours: 'Daily: 11:00 – 20:00',
    featuredDirector: 'Kenji Takahashi, Senior Horological Advisor'
  },
  {
    city: 'London New Bond',
    address: '14 New Bond Street, Mayfair',
    country: 'United Kingdom',
    phone: '+92 3412683864',
    email: 'london@vauban-horlogerie.co.uk',
    hours: 'Mon – Sat: 10:00 – 18:30',
    featuredDirector: 'Arthur Sterling, Private Client Services'
  },
  {
    city: 'Dubai Flagship',
    address: 'The Dubai Mall, Fashion Avenue Suite 44',
    country: 'United Arab Emirates',
    phone: '+92 3412683864',
    email: 'dubai@vauban-horlogerie.ae',
    hours: 'Daily: 10:00 – 23:00',
    featuredDirector: 'Rashid Al-Maktoum, Atelier Specialist'
  }
];
