import React, { useState } from 'react';
import { Header } from './components/Header';
import { HeroSequence } from './components/HeroSequence';
import { Collections } from './components/Collections';
import { ManufactureStory } from './components/ManufactureStory';
import { Ateliers } from './components/Ateliers';
import { Concierge } from './components/Concierge';
import { Footer } from './components/Footer';
import { ProductDetailModal } from './components/ProductDetailModal';
import { CartDrawer, CartItem } from './components/CartDrawer';
import { AppointmentModal } from './components/AppointmentModal';
import { SearchModal } from './components/SearchModal';
import { GoldenTickerLine } from './components/GoldenTickerLine';
import { Product, PRODUCTS } from './data/products';

export default function App() {
  // Shopping Cart state
  const [cartItems, setCartItems] = useState<CartItem[]>([
    {
      product: PRODUCTS[0], // Monolith Skeleton Tourbillon preloaded for immediate delight
      quantity: 1,
      selectedStrap: 'Standard Lined Rubber',
    },
  ]);
  const [isCartOpen, setIsCartOpen] = useState(false);

  // Modals state
  const [selectedProduct, setSelectedProduct] = useState<Product | null>(null);
  const [isAppointmentOpen, setIsAppointmentOpen] = useState(false);
  const [appointmentCity, setAppointmentCity] = useState<string | undefined>(undefined);
  const [isSearchOpen, setIsSearchOpen] = useState(false);

  // Cart operations
  const handleAddToCart = (
    product: Product,
    options?: { strapColor?: string; customEngraving?: string }
  ) => {
    setCartItems((prev) => {
      const existing = prev.find((item) => item.product.id === product.id);
      if (existing) {
        return prev.map((item) =>
          item.product.id === product.id
            ? { ...item, quantity: item.quantity + 1, ...options }
            : item
        );
      }
      return [
        ...prev,
        {
          product,
          quantity: 1,
          selectedStrap: options?.strapColor,
          customEngraving: options?.customEngraving,
        },
      ];
    });
    setIsCartOpen(true);
  };

  const handleUpdateQuantity = (productId: string, quantity: number) => {
    if (quantity <= 0) {
      handleRemoveItem(productId);
      return;
    }
    setCartItems((prev) =>
      prev.map((item) =>
        item.product.id === productId ? { ...item, quantity } : item
      )
    );
  };

  const handleRemoveItem = (productId: string) => {
    setCartItems((prev) => prev.filter((item) => item.product.id !== productId));
  };

  const handleClearCart = () => {
    setCartItems([]);
  };

  // Section navigation helper
  const handleNavigateSection = (sectionId: string) => {
    const el = document.getElementById(sectionId);
    if (el) {
      el.scrollIntoView({ behavior: 'smooth' });
    }
  };

  // Open product detail by ID (e.g. from Hero CTA)
  const handleExploreProductById = (productId: string) => {
    const found = PRODUCTS.find((p) => p.id === productId);
    if (found) {
      setSelectedProduct(found);
    }
  };

  // Open appointment modal with optional city
  const handleBookAppointment = (city?: string) => {
    setAppointmentCity(city);
    setIsAppointmentOpen(true);
  };

  return (
    <div className="min-h-screen w-full max-w-full overflow-x-clip bg-[#070708] text-white flex flex-col font-sans-modern selection:bg-[#C9A050]/30 selection:text-white">
      
      {/* 1. Announcement bar and professional sticky header */}
      <Header
        cartCount={cartItems.reduce((acc, item) => acc + item.quantity, 0)}
        onOpenCart={() => setIsCartOpen(true)}
        onOpenSearch={() => setIsSearchOpen(true)}
        onBookAppointment={() => handleBookAppointment()}
        onNavigateSection={handleNavigateSection}
      />

      <main className="flex-1 w-full max-w-full overflow-x-clip">
        {/* 2. Cinematic scroll-controlled hero section (highest priority, 60 frames) */}
        <HeroSequence
          onExploreProduct={handleExploreProductById}
          onBookAppointment={() => handleBookAppointment()}
        />

        {/* 3. Brand storytelling & in-house manufacture section (About) */}
        <ManufactureStory
          onExploreCollection={() => handleNavigateSection('collections')}
        />

        {/* --- GOLDEN ANIMATED TEXT LINE 1: Transition from Manufacture Story into Curated Collections --- */}
        <GoldenTickerLine
          items={[
            'HAUTE HORLOGERIE SUISSE',
            'FLYING TOURBILLON CALIBRES',
            '18K YELLOW & KING GOLD',
            'GRADE 5 AEROSPACE TITANIUM',
            'MONOCRYSTALLINE SAPPHIRE',
            'CHRONOMETRIC EXCELLENCE',
            'LIMITED ALLOCATIONS',
            'GENEVA PRIVATE ATELIER',
          ]}
          direction="left"
          speedSeconds={36}
        />

        {/* 4. Curated collection section (Products) */}
        <Collections
          onSelectProduct={(product) => setSelectedProduct(product)}
          onAddToCart={(product) => handleAddToCart(product)}
          onBookAppointment={() => handleBookAppointment()}
        />

        {/* --- GOLDEN ANIMATED TEXT LINE 2: Transition from Collections into Global Ateliers --- */}
        <GoldenTickerLine
          items={[
            'IN-HOUSE CALIBRE V-800',
            '290 HAND-ASSEMBLED COMPONENTS',
            '115-HOUR TWIN-BARREL POWER RESERVE',
            '28,800 A/H HIGH FREQUENCY',
            '45° DIAMOND-POLISHED ANGLAGE',
            '10 ATM HERMETIC INTEGRITY',
            'GENEVA SEAL MASTERY',
            'ANTHRACITE RUTHENIUM CALIBRES',
          ]}
          direction="right"
          speedSeconds={38}
        />

        {/* 5. Ateliers & boutiques section */}
        <Ateliers
          onBookAppointment={(city) => handleBookAppointment(city)}
        />

        {/* 6. Concierge & private client services */}
        <Concierge />
      </main>

      {/* 7. Professional footer */}
      <Footer />

      {/* Modals & Overlays */}
      <ProductDetailModal
        product={selectedProduct}
        onClose={() => setSelectedProduct(null)}
        onAddToCart={(product, opts) => handleAddToCart(product, opts)}
        onBookAppointment={() => {
          setSelectedProduct(null);
          handleBookAppointment();
        }}
      />

      <CartDrawer
        isOpen={isCartOpen}
        onClose={() => setIsCartOpen(false)}
        items={cartItems}
        onUpdateQuantity={handleUpdateQuantity}
        onRemoveItem={handleRemoveItem}
        onClearCart={handleClearCart}
      />

      <AppointmentModal
        isOpen={isAppointmentOpen}
        onClose={() => setIsAppointmentOpen(false)}
        initialCity={appointmentCity}
      />

      <SearchModal
        isOpen={isSearchOpen}
        onClose={() => setIsSearchOpen(false)}
        onSelectProduct={(product) => setSelectedProduct(product)}
      />
    </div>
  );
}
