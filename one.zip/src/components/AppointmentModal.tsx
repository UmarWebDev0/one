import React, { useState } from 'react';
import { X, Calendar, Clock, MapPin, CheckCircle2, Sparkles, User, Mail, Phone } from 'lucide-react';
import { BOUTIQUES } from '../data/products';

interface AppointmentModalProps {
  isOpen: boolean;
  onClose: () => void;
  initialCity?: string;
}

export const AppointmentModal: React.FC<AppointmentModalProps> = ({
  isOpen,
  onClose,
  initialCity,
}) => {
  const [confirmed, setConfirmed] = useState(false);
  const [selectedCity, setSelectedCity] = useState(initialCity || BOUTIQUES[0].city);
  const [selectedDate, setSelectedDate] = useState('2026-11-15');
  const [selectedTime, setSelectedTime] = useState('14:00');
  const [formData, setFormData] = useState({
    name: '',
    email: '',
    phone: '',
    guests: '1',
    champagneService: true,
    chauffeurService: false,
    notes: '',
  });

  if (!isOpen) return null;

  const handleSubmit = (e: React.FormEvent) => {
    e.preventDefault();
    setConfirmed(true);
  };

  return (
    <div className="fixed inset-0 z-50 overflow-y-auto bg-black/85 backdrop-blur-md flex items-center justify-center p-3 sm:p-6 animate-in fade-in duration-200">
      <div 
        className="relative w-full max-w-2xl bg-[#0C0C0F] border border-white/10 rounded-sm shadow-2xl p-4 sm:p-10 my-auto"
        onClick={(e) => e.stopPropagation()}
      >
        <button
          onClick={onClose}
          className="absolute top-3 right-3 sm:top-4 sm:right-4 p-1.5 sm:p-2 text-zinc-400 hover:text-white rounded-full hover:bg-white/5 transition-colors cursor-pointer"
        >
          <X className="w-4 h-4 sm:w-5 sm:h-5" />
        </button>

        {confirmed ? (
          <div className="py-6 sm:py-8 text-center space-y-3 sm:space-y-4 animate-in fade-in">
            <div className="w-12 h-12 sm:w-16 sm:h-16 mx-auto rounded-full bg-[#C9A050]/20 border border-[#C9A050]/50 flex items-center justify-center text-[#D8B263]">
              <CheckCircle2 className="w-7 h-7 sm:w-9 sm:h-9" />
            </div>
            <h3 className="font-serif-luxury text-xl sm:text-2xl font-bold text-white">
              PRIVATE SALON APPOINTMENT CONFIRMED
            </h3>
            <p className="text-xs sm:text-sm text-zinc-300 font-sans-modern max-w-md mx-auto leading-relaxed">
              We look forward to welcoming <span className="text-white font-medium">{formData.name}</span> to our <span className="text-[#D8B263]">{selectedCity}</span> atelier on <span className="text-white">{selectedDate}</span> at <span className="text-white">{selectedTime}</span>.
            </p>
            <div className="p-3 sm:p-4 bg-white/5 border border-white/5 rounded-sm max-w-md mx-auto text-left text-[11px] sm:text-xs font-sans-modern space-y-1.5 text-zinc-400">
              <div><strong className="text-white">Salon:</strong> Private Collector Suite</div>
              <div><strong className="text-white">Hospitality:</strong> {formData.champagneService ? 'Vintage Champagne & Canapés' : 'Espresso & Mineral Water'}</div>
              {formData.chauffeurService && <div><strong className="text-white">Logistics:</strong> Chauffeur concierge assigned</div>}
            </div>
            <div className="pt-2 sm:pt-4">
              <button
                onClick={() => {
                  setConfirmed(false);
                  onClose();
                }}
                className="px-5 sm:px-6 py-2 sm:py-2.5 bg-[#D8B263] text-black text-xs font-sans-modern font-semibold uppercase tracking-wider rounded-sm cursor-pointer"
              >
                Done
              </button>
            </div>
          </div>
        ) : (
          <form onSubmit={handleSubmit} className="space-y-3 sm:space-y-4 font-sans-modern text-xs">
            <div className="border-b border-white/10 pb-3 sm:pb-4 mb-3 sm:mb-6">
              <span className="text-[10px] sm:text-xs uppercase tracking-widest text-[#C9A050] font-mono">Exclusive Viewing</span>
              <h2 className="font-serif-luxury text-xl sm:text-2xl font-bold text-white mt-0.5 sm:mt-1">
                RESERVE PRIVATE ATELIER SALON
              </h2>
              <p className="text-zinc-400 text-[11px] sm:text-xs mt-0.5 sm:mt-1">
                Experience our prototype calibres and high-complication timepieces in an intimate salon with our Master Horologist.
              </p>
            </div>

            {/* Atelier Selection */}
            <div>
              <label className="block text-[10px] sm:text-[11px] uppercase tracking-wider text-zinc-400 mb-1 sm:mb-1.5">
                Select Atelier Location *
              </label>
              <select
                value={selectedCity}
                onChange={(e) => setSelectedCity(e.target.value)}
                className="w-full bg-[#141418] border border-white/10 rounded-sm px-3 py-1.5 sm:py-2 text-white text-xs focus:outline-none focus:border-[#C9A050]"
              >
                {BOUTIQUES.map((b) => (
                  <option key={b.city} value={b.city}>
                    {b.city} ({b.country})
                  </option>
                ))}
              </select>
            </div>

            {/* Date & Time */}
            <div className="grid grid-cols-1 sm:grid-cols-2 gap-3 sm:gap-4">
              <div>
                <label className="block text-[10px] sm:text-[11px] uppercase tracking-wider text-zinc-400 mb-1 sm:mb-1.5">
                  Preferred Date *
                </label>
                <input
                  type="date"
                  required
                  value={selectedDate}
                  onChange={(e) => setSelectedDate(e.target.value)}
                  className="w-full bg-[#141418] border border-white/10 rounded-sm px-3 py-1.5 sm:py-2 text-white text-xs focus:outline-none focus:border-[#C9A050]"
                />
              </div>
              <div>
                <label className="block text-[10px] sm:text-[11px] uppercase tracking-wider text-zinc-400 mb-1 sm:mb-1.5">
                  Preferred Time Slot *
                </label>
                <select
                  value={selectedTime}
                  onChange={(e) => setSelectedTime(e.target.value)}
                  className="w-full bg-[#141418] border border-white/10 rounded-sm px-3 py-1.5 sm:py-2 text-white text-xs focus:outline-none focus:border-[#C9A050]"
                >
                  <option value="11:00">11:00 AM (Morning Salon)</option>
                  <option value="14:00">02:00 PM (Afternoon Viewing)</option>
                  <option value="16:30">04:30 PM (Twilight Tasting)</option>
                  <option value="18:30">06:30 PM (Private Evening Reception)</option>
                </select>
              </div>
            </div>

            {/* Guest Details */}
            <div className="grid grid-cols-1 sm:grid-cols-2 gap-3 sm:gap-4">
              <div>
                <label className="block text-[10px] sm:text-[11px] uppercase tracking-wider text-zinc-400 mb-1 sm:mb-1.5">
                  Your Full Name *
                </label>
                <input
                  type="text"
                  required
                  value={formData.name}
                  onChange={(e) => setFormData({ ...formData, name: e.target.value })}
                  placeholder="e.g. Elena Vance"
                  className="w-full bg-[#141418] border border-white/10 rounded-sm px-3 py-1.5 sm:py-2 text-white text-xs focus:outline-none focus:border-[#C9A050]"
                />
              </div>
              <div>
                <label className="block text-[10px] sm:text-[11px] uppercase tracking-wider text-zinc-400 mb-1 sm:mb-1.5">
                  Telephone Contact *
                </label>
                <input
                  type="tel"
                  required
                  value={formData.phone}
                  onChange={(e) => setFormData({ ...formData, phone: e.target.value })}
                  placeholder="+92 3412683864"
                  className="w-full bg-[#141418] border border-white/10 rounded-sm px-3 py-1.5 sm:py-2 text-white text-xs focus:outline-none focus:border-[#C9A050]"
                />
              </div>
            </div>

            <div>
              <label className="block text-[10px] sm:text-[11px] uppercase tracking-wider text-zinc-400 mb-1 sm:mb-1.5">
                Email Address *
              </label>
              <input
                type="email"
                required
                value={formData.email}
                onChange={(e) => setFormData({ ...formData, email: e.target.value })}
                placeholder="client@luxury.ch"
                className="w-full bg-[#141418] border border-white/10 rounded-sm px-3 py-1.5 sm:py-2 text-white text-xs focus:outline-none focus:border-[#C9A050]"
              />
            </div>

            {/* VIP Salon Options */}
            <div className="space-y-1.5 sm:space-y-2 pt-2 border-t border-white/10">
              <label className="flex items-center gap-2 sm:gap-2.5 cursor-pointer text-zinc-300 text-[11px] sm:text-xs">
                <input
                  type="checkbox"
                  checked={formData.champagneService}
                  onChange={(e) => setFormData({ ...formData, champagneService: e.target.checked })}
                  className="rounded border-zinc-700 text-[#C9A050] focus:ring-0"
                />
                <span>Complimentary Grand Cru Champagne & Canapés Reception</span>
              </label>

              <label className="flex items-center gap-2 sm:gap-2.5 cursor-pointer text-zinc-300 text-[11px] sm:text-xs">
                <input
                  type="checkbox"
                  checked={formData.chauffeurService}
                  onChange={(e) => setFormData({ ...formData, chauffeurService: e.target.checked })}
                  className="rounded border-zinc-700 text-[#C9A050] focus:ring-0"
                />
                <span>Private Mercedes-Maybach Chauffeur Pick-Up (Local Radius)</span>
              </label>
            </div>

            <div className="pt-2 sm:pt-4">
              <button
                type="submit"
                className="w-full py-2.5 sm:py-3.5 bg-gradient-to-r from-[#D8B263] to-[#B08A38] text-black font-semibold uppercase tracking-wider rounded-sm hover:brightness-110 transition-all cursor-pointer shadow-lg shadow-[#D8B263]/15 text-xs"
              >
                Confirm Private Atelier Booking
              </button>
            </div>
          </form>
        )}
      </div>
    </div>
  );
};
