import React from 'react';

interface GoldenTickerLineProps {
  items: string[];
  direction?: 'left' | 'right';
  className?: string;
  speedSeconds?: number;
}

export const GoldenTickerLine: React.FC<GoldenTickerLineProps> = ({
  items,
  direction = 'left',
  className = '',
  speedSeconds = 36,
}) => {
  // Duplicate array 6 times (3 copies per half) to guarantee seamless, zero-jump
  // continuous looping on all viewports up to 4K / Ultrawide displays
  const repeatedItems = [...items, ...items, ...items, ...items, ...items, ...items];

  const animationClass = direction === 'left' ? 'animate-marquee-left' : 'animate-marquee-right';

  return (
    <div className={`relative w-full overflow-hidden select-none z-20 ${className}`}>
      
      {/* Upper Whisper-Thin Metallic Gold Line with Soft Highlight */}
      <div className="relative w-full h-[1px] bg-gradient-to-r from-transparent via-[#C5A869]/35 via-[#FFF4DC]/60 to-transparent" />

      {/* Moving Text Marquee Track with Increased Vertical Height & Soft Champagne-Gold Background */}
      <div 
        className="relative w-full py-3.5 sm:py-4.5 overflow-hidden flex items-center justify-center border-y border-[#C5A869]/15 bg-[#0A0A0C]"
        style={{
          background: 'linear-gradient(90deg, rgba(42, 33, 18, 0.70) 0%, rgba(78, 60, 31, 0.72) 12%, rgba(125, 99, 52, 0.74) 25%, rgba(168, 136, 73, 0.75) 38%, rgba(205, 176, 114, 0.76) 50%, rgba(168, 136, 73, 0.75) 62%, rgba(125, 99, 52, 0.74) 75%, rgba(78, 60, 31, 0.72) 88%, rgba(42, 33, 18, 0.70) 100%)',
          boxShadow: 'inset 0 1px 0 0 rgba(255, 248, 230, 0.20), 0 2px 10px rgba(168, 136, 73, 0.08)',
        }}
      >
        {/* Subtle Vertical Satin Finish Layer */}
        <div 
          className="absolute inset-0 pointer-events-none"
          style={{
            background: 'linear-gradient(180deg, rgba(255, 248, 230, 0.16) 0%, rgba(255, 248, 230, 0.04) 32%, rgba(0, 0, 0, 0.03) 60%, rgba(0, 0, 0, 0.20) 100%)',
          }}
        />

        {/* Subtle Horizontal Metallic Sheen Layer */}
        <div 
          className="absolute inset-0 pointer-events-none opacity-30"
          style={{
            background: 'linear-gradient(90deg, transparent 0%, rgba(255, 248, 230, 0.10) 50%, transparent 100%)',
          }}
        />

        {/* Left & Right Soft Edge Vignettes */}
        <div className="absolute left-0 inset-y-0 w-16 sm:w-28 bg-gradient-to-r from-[#0A0A0C] via-[#0A0A0C]/50 to-transparent z-10 pointer-events-none" />
        <div className="absolute right-0 inset-y-0 w-16 sm:w-28 bg-gradient-to-l from-[#0A0A0C] via-[#0A0A0C]/50 to-transparent z-10 pointer-events-none" />

        {/* Seamless Horizontally Moving Typography - Roboto Font, SemiBold, Perfectly Centered */}
        <div 
          className={`${animationClass} flex items-center`}
          style={{ animationDuration: `${speedSeconds}s` }}
        >
          {repeatedItems.map((phrase, idx) => (
            <div 
              key={idx}
              className="flex items-center shrink-0 pr-8 sm:pr-12"
            >
              <span className="font-roboto text-[12px] sm:text-[13px] md:text-[13.5px] uppercase tracking-[0.20em] sm:tracking-[0.24em] font-semibold text-black whitespace-nowrap leading-none flex items-center">
                {phrase}
              </span>
              <span className="ml-8 sm:ml-12 text-black/85 text-[7px] sm:text-[8px] transform rotate-45 select-none shrink-0 inline-flex items-center self-center">
                ◆
              </span>
            </div>
          ))}
        </div>

      </div>

      {/* Lower Whisper-Thin Realistic Metallic Gold Shadow Line */}
      <div className="relative w-full h-[1px] bg-gradient-to-r from-transparent via-[#544018]/35 via-[#7D6334]/40 to-transparent" />

    </div>
  );
};
