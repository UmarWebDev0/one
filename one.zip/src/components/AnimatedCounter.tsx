import React, { useEffect, useState, useRef } from 'react';
import { useInView } from 'motion/react';

interface AnimatedCounterProps {
  target: number;
  duration?: number;
  prefix?: string;
  suffix?: string;
  formatCommas?: boolean;
  className?: string;
}

export const AnimatedCounter: React.FC<AnimatedCounterProps> = ({
  target,
  duration = 1.4,
  prefix = '',
  suffix = '',
  formatCommas = true,
  className = '',
}) => {
  const ref = useRef<HTMLSpanElement>(null);
  const isInView = useInView(ref, { once: false, amount: 0.25 });
  const [currentValue, setCurrentValue] = useState(0);

  useEffect(() => {
    if (isInView) {
      let startTimestamp: number | null = null;
      let frameId: number;

      const step = (timestamp: number) => {
        if (!startTimestamp) startTimestamp = timestamp;
        const elapsed = timestamp - startTimestamp;
        const progress = Math.min(elapsed / (duration * 1000), 1);

        // Exponential ease-out for luxurious smooth deceleration
        const ease = progress === 1 ? 1 : 1 - Math.pow(2, -10 * progress);
        setCurrentValue(Math.round(ease * target));

        if (progress < 1) {
          frameId = requestAnimationFrame(step);
        }
      };

      frameId = requestAnimationFrame(step);

      return () => {
        if (frameId) cancelAnimationFrame(frameId);
      };
    } else {
      // Reset when scrolled out of view so it replays every time on scroll
      setCurrentValue(0);
    }
  }, [isInView, target, duration]);

  const formattedNumber = formatCommas
    ? currentValue.toLocaleString()
    : currentValue.toString();

  return (
    <span ref={ref} className={`tabular-nums ${className}`}>
      {prefix}
      {formattedNumber}
      {suffix}
    </span>
  );
};
