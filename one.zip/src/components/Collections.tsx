import React, { useState, useEffect, useRef } from 'react';
import { Product, PRODUCTS } from '../data/products';
import { motion, AnimatePresence } from 'motion/react';
import { 
  Plus, 
  X, 
  ArrowUpRight, 
  Check, 
  LayoutGrid, 
  ListFilter, 
  Eye
} from 'lucide-react';

interface CollectionsProps {
  onSelectProduct: (product: Product) => void;
  onAddToCart: (product: Product, options?: { strapColor?: string; customEngraving?: string }) => void;
  onBookAppointment?: (city?: string) => void;
}

export const Collections: React.FC<CollectionsProps> = ({
  onSelectProduct,
  onAddToCart,
  onBookAppointment,
}) => {
  const [activeStyle, setActiveStyle] = useState<string>('all');
  const [viewMode, setViewMode] = useState<'rows' | 'grid'>('rows');
  const [hoveredProduct, setHoveredProduct] = useState<Product | null>(null);
  const [mousePos, setMousePos] = useState<{ x: number; y: number }>({ x: -9999, y: -9999 });
  const [popupProduct, setPopupProduct] = useState<Product | null>(null);
  const [activeImageAngle, setActiveImageAngle] = useState<'primary' | 'alternate'>('primary');
  const [addedIds, setAddedIds] = useState<Set<string>>(new Set());

  const containerRef = useRef<HTMLDivElement>(null);

  const styleFilters = [
    { id: 'all', label: 'All References', count: PRODUCTS.length },
    { id: 'Chronograph', label: 'Chronographs', count: PRODUCTS.filter(p => p.style === 'Chronograph').length },
    { id: 'Skeleton', label: 'Skeleton & Tourbillon', count: PRODUCTS.filter(p => p.style === 'Skeleton').length },
    { id: 'Gold', label: 'Precious Gold', count: PRODUCTS.filter(p => p.style === 'Gold').length },
    { id: 'Ceramic', label: 'High-Tech Ceramic', count: PRODUCTS.filter(p => p.style === 'Ceramic').length },
    { id: 'Sport', label: 'Sport & Diver', count: PRODUCTS.filter(p => p.style === 'Sport').length },
    { id: 'Classic', label: 'Classic Dress', count: PRODUCTS.filter(p => p.style === 'Classic').length },
  ];

  const filteredProducts = activeStyle === 'all'
    ? PRODUCTS
    : PRODUCTS.filter(p => p.style === activeStyle);

  // Reset angle when opening a new compact popup
  useEffect(() => {
    setActiveImageAngle('primary');
  }, [popupProduct]);

  // Lock scroll and handle ESC key for popup
  useEffect(() => {
    const handleKeyDown = (e: KeyboardEvent) => {
      if (e.key === 'Escape') {
        setPopupProduct(null);
      }
    };

    if (popupProduct) {
      document.body.style.overflow = 'hidden';
      window.addEventListener('keydown', handleKeyDown);
    } else {
      document.body.style.overflow = '';
    }

    return () => {
      document.body.style.overflow = '';
      window.removeEventListener('keydown', handleKeyDown);
    };
  }, [popupProduct]);

  // Precise cursor tracking for floating preview
  const updateMousePosition = (clientX: number, clientY: number) => {
    const cardWidth = 260;
    const cardHeight = 310;
    const padding = 16;

    let x = clientX + 18;
    let y = clientY - 80;

    // Boundary detection: if close to right edge, flip to left side of cursor
    if (x + cardWidth > window.innerWidth - padding) {
      x = clientX - cardWidth - 18;
    }
    // Boundary detection: if close to bottom edge, shift upward
    if (y + cardHeight > window.innerHeight - padding) {
      y = window.innerHeight - cardHeight - padding;
    }
    // Boundary detection: if close to top edge
    if (y < padding) {
      y = padding;
    }

    setMousePos({ x, y });
  };

  const handleQuickAdd = (e: React.MouseEvent, product: Product) => {
    e.stopPropagation();
    onAddToCart(product);
    setAddedIds((prev) => new Set(prev).add(product.id));
    setTimeout(() => {
      setAddedIds((prev) => {
        const next = new Set(prev);
        next.delete(product.id);
        return next;
      });
    }, 2000);
  };

  return (
    <section 
      id="collections" 
      ref={containerRef}
      className="py-14 sm:py-28 bg-[#08080A] border-t border-white/10 relative overflow-hidden text-white"
    >
      
      <div className="max-w-7xl mx-auto px-5 sm:px-8 lg:px-12 relative z-10">
        
        {/* Section Header with Scroll-Replay Animation */}
        <motion.div 
          initial={{ opacity: 0, y: 20 }}
          whileInView={{ opacity: 1, y: 0 }}
          viewport={{ once: false, amount: 0.2 }}
          transition={{ duration: 0.5, ease: [0.16, 1, 0.3, 1] }}
          className="flex flex-col lg:flex-row lg:items-end justify-between gap-4 sm:gap-6 mb-6 sm:mb-10"
        >
          <div>
            <div className="flex items-center gap-2.5 text-[10px] sm:text-[11px] tracking-[0.25em] sm:tracking-[0.28em] text-[#D8B263] uppercase font-sans-modern font-semibold mb-2 sm:mb-2.5">
              <span className="w-5 h-[1px] bg-[#D8B263]" />
              <span>Haute Horlogerie Catalog</span>
            </div>
            <h2 className="font-serif-luxury text-xl sm:text-3xl lg:text-4xl font-semibold text-white tracking-tight">
              CURATED MANUFACTURE REFERENCES
            </h2>
          </div>

          <div className="flex flex-col sm:flex-row sm:items-center justify-between lg:justify-end gap-3 sm:gap-5">
            <p className="max-w-xs text-[11px] sm:text-xs text-zinc-400 font-sans-modern leading-relaxed">
              Master-crafted timepieces cast in noble gold, aerospace titanium, high-tech ceramic, and sapphire crystal.
            </p>

            {/* View Mode Toggle */}
            <div className="flex items-center gap-1 p-1 bg-white/5 border border-white/10 rounded-xs self-start sm:self-auto">
              <button
                onClick={() => setViewMode('rows')}
                className={`p-1.5 rounded-xs transition-all cursor-pointer ${
                  viewMode === 'rows'
                    ? 'bg-[#D8B263] text-black shadow-sm'
                    : 'text-zinc-400 hover:text-white'
                }`}
                aria-label="Interactive Rows View"
                title="Interactive Rows View"
              >
                <ListFilter className="w-3.5 h-3.5" />
              </button>
              <button
                onClick={() => setViewMode('grid')}
                className={`p-1.5 rounded-xs transition-all cursor-pointer ${
                  viewMode === 'grid'
                    ? 'bg-[#D8B263] text-black shadow-sm'
                    : 'text-zinc-400 hover:text-white'
                }`}
                aria-label="Grid View"
                title="Grid View"
              >
                <LayoutGrid className="w-3.5 h-3.5" />
              </button>
            </div>
          </div>
        </motion.div>

        {/* Style Filter Tabs with Scroll-Replay Animation - Horizontally Scrollable without horizontal overflow */}
        <motion.div 
          initial={{ opacity: 0, y: 16 }}
          whileInView={{ opacity: 1, y: 0 }}
          viewport={{ once: false, amount: 0.2 }}
          transition={{ duration: 0.45, delay: 0.08, ease: [0.16, 1, 0.3, 1] }}
          className="flex items-center gap-2 overflow-x-auto overflow-y-hidden flex-nowrap pb-2.5 sm:pb-3 mb-6 sm:mb-10 w-full max-w-full scroll-smooth touch-pan-x [scrollbar-width:none] [-ms-overflow-style:none] [&::-webkit-scrollbar]:hidden"
        >
          {styleFilters.map((tab) => {
            const isActive = activeStyle === tab.id;
            return (
              <button
                key={tab.id}
                onClick={() => setActiveStyle(tab.id)}
                className={`px-3 py-1.5 sm:px-3.5 sm:py-1.5 text-[10.5px] sm:text-[11px] font-sans-modern font-medium uppercase tracking-wider rounded-xs transition-all whitespace-nowrap shrink-0 flex items-center gap-1.5 sm:gap-2 cursor-pointer ${
                  isActive
                    ? 'bg-gradient-to-r from-[#D8B263] via-[#E0C079] to-[#B68D3C] text-black font-bold shadow-md shadow-[#D8B263]/25 border border-[#D8B263]'
                    : 'bg-[#121217] text-zinc-300 hover:text-white hover:bg-white/10 border border-white/10 active:scale-95'
                }`}
              >
                <span>{tab.label}</span>
                <span className={`text-[9.5px] sm:text-[10px] font-mono px-1.5 py-0.2 rounded-full ${
                  isActive ? 'bg-black/25 text-black font-bold' : 'bg-white/10 text-zinc-400'
                }`}>
                  {tab.count}
                </span>
              </button>
            );
          })}
        </motion.div>

        {/* ===================== VIEW 1: MINIMAL HORIZONTAL PROJECT ROWS ===================== */}
        {viewMode === 'rows' && (
          <div className="border-t border-white/10 divide-y divide-white/10 relative">
            {filteredProducts.map((product, idx) => {
              const isAdded = addedIds.has(product.id);

              return (
                <motion.div
                  key={product.id}
                  initial={{ opacity: 0, y: 20 }}
                  whileInView={{ opacity: 1, y: 0 }}
                  viewport={{ once: false, amount: 0.15 }}
                  transition={{ 
                    duration: 0.5, 
                    delay: (idx % 4) * 0.05,
                    ease: [0.16, 1, 0.3, 1] 
                  }}
                  onMouseEnter={(e) => {
                    if (window.innerWidth >= 768) {
                      updateMousePosition(e.clientX, e.clientY);
                      setHoveredProduct(product);
                    }
                  }}
                  onMouseMove={(e) => {
                    if (window.innerWidth >= 768) {
                      updateMousePosition(e.clientX, e.clientY);
                      if (hoveredProduct?.id !== product.id) {
                        setHoveredProduct(product);
                      }
                    }
                  }}
                  onMouseLeave={() => {
                    setHoveredProduct(null);
                  }}
                  onClick={() => setPopupProduct(product)}
                  className="group relative py-3.5 sm:py-6 md:py-6.5 px-2 sm:px-6 flex flex-col md:flex-row md:items-center justify-between gap-3 sm:gap-6 cursor-pointer transition-all duration-300 hover:bg-white/[0.02]"
                >
                  {/* Subtle golden left hairline indicator on hover */}
                  <div className="absolute left-0 top-1/2 -translate-y-1/2 w-0 group-hover:w-1 h-0 group-hover:h-8 bg-[#D8B263] transition-all duration-300 rounded-r-xs" />

                  {/* Left Column: Index, Metadata, and Elegant Minimal Title */}
                  <div className="flex items-center gap-3 sm:gap-6 flex-1 min-w-0">
                    
                    {/* Index Number */}
                    <span className="text-[11px] sm:text-xs font-mono text-zinc-600 group-hover:text-[#D8B263] transition-colors shrink-0">
                      {String(idx + 1).padStart(2, '0')}
                    </span>

                    {/* Mobile Inline Image Thumbnail - Compact & Crisp */}
                    <div className="w-12 h-12 sm:w-16 sm:h-16 bg-[#111116] border border-white/10 p-1 sm:p-1.5 rounded-xs shrink-0 flex md:hidden items-center justify-center overflow-hidden relative">
                      <div className="absolute inset-0 bg-radial from-[#D8B263]/10 to-transparent pointer-events-none" />
                      <img
                        src={product.image}
                        alt={product.name}
                        loading="lazy"
                        referrerPolicy="no-referrer"
                        className="w-full h-full object-contain filter drop-shadow-[0_4px_8px_rgba(0,0,0,0.85)] group-hover:scale-105 transition-transform duration-300"
                      />
                    </div>

                    {/* Metadata & Title Block */}
                    <div className="flex-1 min-w-0">
                      
                      {/* Small Category Labels & Project Year Information */}
                      <div className="flex flex-wrap items-center gap-1.5 sm:gap-2 text-[9px] sm:text-[10px] font-mono uppercase tracking-[0.16em] sm:tracking-[0.2em] text-[#D8B263] mb-0.5 sm:mb-1">
                        <span className="font-medium">{product.category}</span>
                        <span className="text-zinc-600">/</span>
                        <span className="text-zinc-400">{product.year || '2026'}</span>
                        <span className="text-zinc-600 hidden sm:inline">/</span>
                        <span className="text-zinc-500 hidden sm:inline">{product.reference}</span>
                      </div>

                      {/* Slightly smaller, elegant, minimal project title on mobile */}
                      <h3 className="font-serif-luxury text-[15px] sm:text-2xl md:text-3xl font-medium tracking-tight text-white group-hover:text-[#D8B263] transition-all duration-300 group-hover:translate-x-1.5 leading-snug truncate sm:whitespace-normal">
                        {product.name}
                      </h3>

                      {/* Micro summary */}
                      <p className="text-[11px] sm:text-xs text-zinc-400 font-sans-modern mt-0.5 line-clamp-1 max-w-xl group-hover:text-zinc-300 transition-colors">
                        {product.material} · {product.caseSize} · {product.calibre.split(' ')[0]} {product.calibre.split(' ')[1] || ''}
                      </p>
                    </div>

                  </div>

                  {/* Right Column: Price and Circular Arrow Icon */}
                  <div className="flex items-center justify-between md:justify-end gap-3 sm:gap-8 shrink-0 pt-2 sm:pt-0 border-t border-white/5 md:border-t-0">
                    
                    {/* Price Block */}
                    <div className="text-left md:text-right">
                      <div className="text-[8px] sm:text-[9px] uppercase tracking-[0.18em] sm:tracking-[0.2em] text-zinc-500 font-sans-modern">Manufacture Price</div>
                      <div className="text-xs sm:text-base md:text-lg font-serif-luxury font-medium text-white tabular-nums">
                        ${product.price.toLocaleString()}{' '}
                        <span className="text-[9px] sm:text-[10px] font-sans-modern font-normal text-zinc-500">USD</span>
                      </div>
                    </div>

                    {/* Action Group */}
                    <div className="flex items-center gap-2 sm:gap-2.5">
                      
                      {/* Quick Add Button */}
                      <button
                        type="button"
                        onClick={(e) => handleQuickAdd(e, product)}
                        className={`w-7 h-7 sm:w-9 sm:h-9 rounded-full border flex items-center justify-center transition-all duration-300 cursor-pointer ${
                          isAdded
                            ? 'bg-emerald-600 text-white border-emerald-500'
                            : 'bg-white/5 hover:bg-[#D8B263] border-white/20 hover:border-[#D8B263] text-white hover:text-black'
                        }`}
                        aria-label="Add to bag"
                        title="Add to Shopping Bag"
                      >
                        {isAdded ? <Check className="w-3 h-3 sm:w-3.5 sm:h-3.5" /> : <Plus className="w-3 h-3 sm:w-3.5 sm:h-3.5 transition-transform group-hover:rotate-90" />}
                      </button>

                      {/* Circular Arrow Icon */}
                      <div className="w-7 h-7 sm:w-10 sm:h-10 rounded-full border border-white/15 group-hover:border-[#D8B263] group-hover:bg-[#D8B263] group-hover:text-black flex items-center justify-center text-white transition-all duration-300 shrink-0 shadow-sm">
                        <ArrowUpRight className="w-3 h-3 sm:w-4 sm:h-4 transition-transform duration-300 group-hover:rotate-45 group-hover:scale-105" />
                      </div>

                    </div>

                  </div>

                </motion.div>
              );
            })}
          </div>
        )}

        {/* ===================== VIEW 2: COMPACT VITRINE GRID ===================== */}
        {viewMode === 'grid' && (
          <div className="grid grid-cols-1 sm:grid-cols-2 md:grid-cols-3 lg:grid-cols-4 gap-4 sm:gap-4.5">
            {filteredProducts.map((product, idx) => {
              const isAdded = addedIds.has(product.id);

              return (
                <motion.div
                  key={product.id}
                  initial={{ opacity: 0, y: 20, scale: 0.98 }}
                  whileInView={{ opacity: 1, y: 0, scale: 1 }}
                  viewport={{ once: false, amount: 0.15 }}
                  transition={{ 
                    duration: 0.45, 
                    delay: (idx % 4) * 0.04,
                    ease: [0.16, 1, 0.3, 1] 
                  }}
                  onMouseEnter={(e) => {
                    updateMousePosition(e.clientX, e.clientY);
                    setHoveredProduct(product);
                  }}
                  onMouseMove={(e) => {
                    updateMousePosition(e.clientX, e.clientY);
                    if (hoveredProduct?.id !== product.id) {
                      setHoveredProduct(product);
                    }
                  }}
                  onMouseLeave={() => {
                    setHoveredProduct(null);
                  }}
                  onClick={() => setPopupProduct(product)}
                  className="group relative bg-[#0C0C10] border border-white/[0.08] hover:border-[#D8B263]/50 rounded-xs overflow-hidden flex flex-col justify-between transition-all duration-300 ease-out cursor-pointer hover:-translate-y-1 hover:shadow-[0_14px_30px_rgba(0,0,0,0.85)]"
                >
                  {/* Top Bar */}
                  <div className="px-3.5 pt-3 pb-0 flex items-center justify-between text-[9px] font-mono pointer-events-none z-20">
                    <span className="text-[#D8B263] uppercase tracking-[0.16em] bg-black/60 backdrop-blur-md px-2 py-0.5 border border-[#D8B263]/30 rounded-xs truncate max-w-[120px]">
                      {product.badge || product.style}
                    </span>
                    <span className="text-zinc-400 bg-white/5 backdrop-blur-md px-1.5 py-0.5 border border-white/10 rounded-xs shrink-0">
                      {product.year || '2026'} · {product.caseSize}
                    </span>
                  </div>

                  {/* Main Watch Photography Showcase Stage - Compact & Well-Proportioned */}
                  <div className="relative h-36 sm:h-40 w-full bg-gradient-to-b from-[#111116] via-[#0E0E12] to-[#0A0A0D] overflow-hidden flex items-center justify-center p-3 mt-1">
                    <div className="absolute inset-0 bg-[radial-gradient(circle_at_center,_rgba(216,178,99,0.1)_0%,_rgba(0,0,0,0)_68%)] pointer-events-none transition-opacity duration-500 group-hover:opacity-100 opacity-40" />
                    <div className="absolute bottom-2.5 w-24 h-2.5 bg-black/70 rounded-full blur-md pointer-events-none" />

                    <img
                      src={product.image}
                      alt={product.name}
                      loading="lazy"
                      referrerPolicy="no-referrer"
                      className="max-h-[120px] sm:max-h-[132px] w-auto max-w-full object-contain filter drop-shadow-[0_12px_22px_rgba(0,0,0,0.88)] transition-all duration-500 ease-out group-hover:scale-105"
                    />

                    <div className="absolute bottom-2 right-2 z-20 opacity-0 group-hover:opacity-100 transition-all duration-200 translate-y-0.5 group-hover:translate-y-0">
                      <div className="px-2 py-0.5 bg-black/85 backdrop-blur-md border border-[#D8B263]/40 text-[8.5px] font-mono text-[#D8B263] flex items-center gap-1 rounded-xs shadow-md">
                        <Eye className="w-2.5 h-2.5 text-[#D8B263]" />
                        <span>Preview</span>
                        <ArrowUpRight className="w-2.5 h-2.5 text-[#D8B263]" />
                      </div>
                    </div>
                  </div>

                  {/* Card Content & Metadata Block - Compact Typography */}
                  <div className="p-3.5 bg-gradient-to-b from-[#0C0C10] to-[#070709] flex flex-col justify-between flex-1 border-t border-white/[0.06]">
                    <div>
                      <div className="flex items-center gap-1.5 text-[9px] font-mono text-zinc-400 mb-1">
                        <span className="text-[#D8B263] uppercase tracking-wider font-medium">{product.style}</span>
                        <span>·</span>
                        <span className="truncate text-zinc-400">{product.reference}</span>
                      </div>

                      <h3 className="font-serif-luxury text-sm font-medium text-white group-hover:text-[#D8B263] transition-colors mb-1 leading-snug line-clamp-1">
                        {product.name}
                      </h3>

                      <p className="text-[11px] text-zinc-400 font-sans-modern line-clamp-1 mb-2.5">
                        {product.material}
                      </p>
                    </div>

                    <div className="pt-2.5 border-t border-white/[0.08] flex items-center justify-between">
                      <div>
                        <div className="text-[8px] uppercase tracking-[0.18em] text-zinc-500 font-sans-modern">Price</div>
                        <div className="text-sm font-serif-luxury font-medium text-white tabular-nums">
                          ${product.price.toLocaleString()}{' '}
                          <span className="text-[8.5px] font-sans-modern font-normal text-zinc-500">USD</span>
                        </div>
                      </div>

                      <div className="flex items-center gap-1">
                        <button
                          type="button"
                          onClick={(e) => handleQuickAdd(e, product)}
                          className={`w-7 h-7 rounded-full border flex items-center justify-center transition-all duration-300 cursor-pointer ${
                            isAdded
                              ? 'bg-emerald-600 text-white border-emerald-500'
                              : 'bg-white/5 hover:bg-[#D8B263] border-white/20 hover:border-[#D8B263] text-white hover:text-black'
                          }`}
                          aria-label="Add to bag"
                        >
                          {isAdded ? <Check className="w-3 h-3" /> : <Plus className="w-3 h-3" />}
                        </button>
                      </div>
                    </div>
                  </div>

                </motion.div>
              );
            })}
          </div>
        )}

        {/* ===================== 1. FLOATING PROJECT IMAGE PREVIEW (IMMEDIATE HOVER & MOUSE MOVEMENT) ===================== */}
        <AnimatePresence>
          {hoveredProduct && (
            <motion.div
              key="floating-preview-card"
              initial={{ opacity: 0, scale: 0.9 }}
              animate={{ 
                opacity: 1, 
                scale: 1, 
                x: mousePos.x,
                y: mousePos.y,
              }}
              exit={{ opacity: 0, scale: 0.88 }}
              transition={{ 
                opacity: { duration: 0.12 },
                scale: { duration: 0.12 },
                x: { type: 'spring', damping: 28, stiffness: 380, mass: 0.35 },
                y: { type: 'spring', damping: 28, stiffness: 380, mass: 0.35 },
              }}
              style={{ 
                position: 'fixed',
                top: 0,
                left: 0,
                pointerEvents: 'none',
                zIndex: 9999,
              }}
              className="hidden md:flex w-60 sm:w-64 h-72 sm:h-76 bg-[#0C0C10]/95 backdrop-blur-2xl border border-[#D8B263]/40 rounded-xs shadow-[0_20px_45px_rgba(0,0,0,0.95)] p-3.5 flex-col justify-between overflow-hidden"
            >
              {/* Subtle amber radial lighting glow */}
              <div className="absolute inset-0 bg-[radial-gradient(ellipse_at_center,_rgba(216,178,99,0.18)_0%,_rgba(0,0,0,0)_70%)] pointer-events-none" />

              {/* Minimal header */}
              <div className="flex items-center justify-between text-[9px] font-mono relative z-10">
                <span className="text-[#D8B263] uppercase tracking-wider font-semibold">
                  {hoveredProduct.style}
                </span>
                <span className="text-zinc-400 bg-white/10 px-2 py-0.5 rounded-xs border border-white/10">
                  {hoveredProduct.year || '2026'} · {hoveredProduct.caseSize}
                </span>
              </div>

              {/* Main Floating Watch Photograph */}
              <div className="relative my-auto flex items-center justify-center aspect-square max-h-[155px] z-10 py-1">
                <div className="absolute bottom-1.5 w-28 h-3 bg-black/80 rounded-full blur-md" />
                <img
                  key={hoveredProduct.id}
                  src={hoveredProduct.image}
                  alt={hoveredProduct.name}
                  className="w-full h-full object-contain filter drop-shadow-[0_12px_20px_rgba(0,0,0,0.95)] transform scale-102 transition-opacity duration-200"
                />
              </div>

              {/* Minimal preview footer */}
              <div className="relative z-10 pt-2 border-t border-white/10 flex items-center justify-between">
                <div className="min-w-0 pr-2">
                  <div className="text-xs font-serif-luxury font-medium text-white truncate max-w-[140px]">
                    {hoveredProduct.name}
                  </div>
                  <div className="text-[10px] font-mono text-[#D8B263] font-medium">
                    ${hoveredProduct.price.toLocaleString()} USD
                  </div>
                </div>

                <div className="px-2 py-0.5 bg-white/5 border border-white/10 text-[9px] font-mono text-zinc-300 flex items-center gap-1 uppercase tracking-wider rounded-xs">
                  <span>View</span>
                  <ArrowUpRight className="w-2.5 h-2.5 text-[#D8B263]" />
                </div>
              </div>

            </motion.div>
          )}
        </AnimatePresence>

        {/* ===================== 2. REDUCED SIZE & COMPACT IMAGE PREVIEW POPUP (ON CLICK) ===================== */}
        <AnimatePresence>
          {popupProduct && (
            <motion.div 
              initial={{ opacity: 0 }}
              animate={{ opacity: 1 }}
              exit={{ opacity: 0 }}
              transition={{ duration: 0.2 }}
              className="fixed inset-0 z-50 overflow-y-auto bg-black/15 flex items-center justify-center p-4"
              onClick={() => setPopupProduct(null)}
            >
              <motion.div
                initial={{ opacity: 0, scale: 0.92, y: 12 }}
                animate={{ opacity: 1, scale: 1, y: 0 }}
                exit={{ opacity: 0, scale: 0.93, y: 8 }}
                transition={{ duration: 0.25, ease: [0.16, 1, 0.3, 1] }}
                className="relative w-full max-w-[330px] sm:max-w-[350px] bg-[#0E0E13]/95 backdrop-blur-xl border border-[#D8B263]/50 rounded-xs shadow-[0_25px_60px_rgba(0,0,0,0.85)] overflow-hidden my-auto p-4 sm:p-5"
                onClick={(e) => e.stopPropagation()}
              >
                {/* Header: Category / Year & Compact Close Button */}
                <div className="flex items-center justify-between pb-2.5 border-b border-white/10">
                  <div className="flex items-center gap-1.5 text-[9px] font-mono text-[#D8B263] uppercase tracking-wider">
                    <span className="font-semibold">{popupProduct.category}</span>
                    <span className="text-zinc-600">·</span>
                    <span className="text-zinc-400">{popupProduct.year || '2026'}</span>
                  </div>

                  <button
                    onClick={() => setPopupProduct(null)}
                    className="w-6 h-6 rounded-full bg-white/10 hover:bg-white/20 text-zinc-400 hover:text-white transition-colors flex items-center justify-center cursor-pointer"
                    aria-label="Close preview"
                    title="Close (ESC)"
                  >
                    <X className="w-3.5 h-3.5" />
                  </button>
                </div>

                {/* Compact Watch Photography Stage */}
                <div className="relative my-3 h-40 sm:h-44 bg-gradient-to-b from-[#131318] to-[#0A0A0D] border border-white/5 rounded-xs flex items-center justify-center p-3 overflow-hidden">
                  <div className="absolute inset-0 bg-[radial-gradient(circle_at_center,_rgba(216,178,99,0.14)_0%,_rgba(0,0,0,0)_70%)] pointer-events-none" />
                  <div className="absolute bottom-2.5 w-28 h-2.5 bg-black/80 rounded-full blur-md pointer-events-none" />

                  <img
                    src={activeImageAngle === 'primary' ? popupProduct.image : (popupProduct.hoverImage || popupProduct.image)}
                    alt={popupProduct.name}
                    referrerPolicy="no-referrer"
                    className="w-full h-full object-contain filter drop-shadow-[0_12px_20px_rgba(0,0,0,0.95)] transition-all duration-200"
                  />

                  {/* Dual angle toggle if available */}
                  {popupProduct.hoverImage && (
                    <div className="absolute bottom-2 inset-x-0 flex justify-center gap-1 z-10">
                      <button
                        type="button"
                        onClick={() => setActiveImageAngle('primary')}
                        className={`px-2 py-0.5 text-[8px] font-mono tracking-wider uppercase rounded-xs transition-all cursor-pointer ${
                          activeImageAngle === 'primary'
                            ? 'bg-[#D8B263] text-black font-semibold'
                            : 'bg-black/70 text-zinc-400 hover:text-white border border-white/10 backdrop-blur-sm'
                        }`}
                      >
                        Front
                      </button>
                      <button
                        type="button"
                        onClick={() => setActiveImageAngle('alternate')}
                        className={`px-2 py-0.5 text-[8px] font-mono tracking-wider uppercase rounded-xs transition-all cursor-pointer ${
                          activeImageAngle === 'alternate'
                            ? 'bg-[#D8B263] text-black font-semibold'
                            : 'bg-black/70 text-zinc-400 hover:text-white border border-white/10 backdrop-blur-sm'
                        }`}
                      >
                        Angle
                      </button>
                    </div>
                  )}
                </div>

                {/* Compact Info Section */}
                <div>
                  <div className="flex items-baseline justify-between gap-2">
                    <h3 className="font-serif-luxury text-base font-medium text-white truncate">
                      {popupProduct.name}
                    </h3>
                    <div className="text-sm font-serif-luxury font-bold text-[#D8B263] tabular-nums shrink-0">
                      ${popupProduct.price.toLocaleString()}
                    </div>
                  </div>

                  <p className="text-[11px] text-zinc-400 font-sans-modern line-clamp-1 mt-0.5">
                    {popupProduct.material}
                  </p>

                  {/* Micro Specs Line */}
                  <div className="flex items-center gap-2 py-1.5 px-2 bg-white/[0.03] border border-white/5 rounded-xs text-[9px] font-mono text-zinc-400 my-2.5">
                    <span>{popupProduct.caseSize}</span>
                    <span className="text-zinc-600">·</span>
                    <span className="truncate">{popupProduct.calibre.split(' ')[1] || 'V-4130'}</span>
                    <span className="text-zinc-600">·</span>
                    <span>{popupProduct.powerReserve}</span>
                  </div>

                  {/* Compact Action Buttons */}
                  <div className="flex items-center gap-2 pt-0.5">
                    <button
                      onClick={(e) => handleQuickAdd(e, popupProduct)}
                      className={`flex-1 py-2 px-3 font-sans-modern text-[10px] font-semibold tracking-wider uppercase rounded-xs transition-all flex items-center justify-center gap-1.5 cursor-pointer shadow-sm shadow-[#D8B263]/20 ${
                        addedIds.has(popupProduct.id)
                          ? 'bg-emerald-600 text-white'
                          : 'bg-gradient-to-r from-[#D8B263] to-[#B08A38] text-black hover:brightness-110'
                      }`}
                    >
                      {addedIds.has(popupProduct.id) ? (
                        <>
                          <Check className="w-3 h-3" />
                          <span>Added</span>
                        </>
                      ) : (
                        <>
                          <span>Acquire</span>
                          <ArrowUpRight className="w-3 h-3" />
                        </>
                      )}
                    </button>

                    {onBookAppointment && (
                      <button
                        onClick={() => {
                          setPopupProduct(null);
                          onBookAppointment();
                        }}
                        className="py-2 px-2.5 border border-white/20 text-white hover:border-[#D8B263] hover:text-[#D8B263] font-sans-modern text-[10px] uppercase tracking-wider rounded-xs transition-all cursor-pointer whitespace-nowrap"
                      >
                        Salon View
                      </button>
                    )}
                  </div>
                </div>

              </motion.div>
            </motion.div>
          )}
        </AnimatePresence>

      </div>
    </section>
  );
};
