import React, { useState } from 'react';
import { BOUTIQUES, Boutique } from '../data/products';
import { MapPin, Phone, Mail, Clock, Calendar, ChevronRight } from 'lucide-react';
import { motion } from 'motion/react';

interface AteliersProps {
  onBookAppointment: (selectedCity?: string) => void;
}

export const Ateliers: React.FC<AteliersProps> = ({ onBookAppointment }) => {
  const [selectedBoutique, setSelectedBoutique] = useState<Boutique>(BOUTIQUES[0]);

  return (
    <section id="ateliers" className="pt-12 sm:pt-28 pb-10 sm:pb-20 bg-[#09090B] border-t border-white/5 relative">
      <div className="max-w-7xl mx-auto px-5 sm:px-8 lg:px-12">
        
        {/* Header with Scroll-Replay Animation */}
        <motion.div 
          initial={{ opacity: 0, y: 24 }}
          whileInView={{ opacity: 1, y: 0 }}
          viewport={{ once: false, amount: 0.2 }}
          transition={{ duration: 0.55, ease: [0.16, 1, 0.3, 1] }}
          className="flex flex-col md:flex-row md:items-end justify-between gap-4 sm:gap-8 mb-8 sm:mb-16"
        >
          <div>
            <div className="flex items-center gap-2 text-[10px] sm:text-xs tracking-[0.25em] text-[#C9A050] uppercase font-sans-modern font-semibold mb-2 sm:mb-3">
              <span>Worldwide Presence</span>
              <span className="w-8 h-[1px] bg-[#C9A050]/50" />
            </div>
            <h2 className="font-serif-luxury text-2xl sm:text-4xl lg:text-5xl font-bold text-white tracking-tight text-balance">
              ATELIERS & BOUTIQUES
            </h2>
          </div>

          <p className="max-w-md text-xs sm:text-sm text-zinc-400 font-sans-modern leading-relaxed">
            Experience our timepieces in private salon environments. Dedicated horologists provide bespoke fittings, champagne receptions, and technical consultations.
          </p>
        </motion.div>

        {/* 2-Column Split: Boutique List Left, Interactive Boutique Detail Card Right */}
        <div className="grid grid-cols-1 lg:grid-cols-12 gap-6 sm:gap-8 items-start">
          
          {/* Left Column: City Selector List with Scroll-Replay Animation */}
          <motion.div 
            initial={{ opacity: 0, x: -20 }}
            whileInView={{ opacity: 1, x: 0 }}
            viewport={{ once: false, amount: 0.2 }}
            transition={{ duration: 0.55, delay: 0.1, ease: [0.16, 1, 0.3, 1] }}
            className="lg:col-span-5 space-y-2.5 sm:space-y-3"
          >
            {BOUTIQUES.map((b) => {
              const isSelected = selectedBoutique.city === b.city;
              return (
                <button
                  key={b.city}
                  onClick={() => setSelectedBoutique(b)}
                  className={`w-full text-left p-3.5 sm:p-5 rounded-sm transition-all border cursor-pointer flex items-center justify-between ${
                    isSelected
                      ? 'bg-[#141418] border-[#C9A050]/60 text-white shadow-lg'
                      : 'bg-[#0E0E12] border-white/5 text-zinc-400 hover:text-white hover:bg-[#121216]'
                  }`}
                >
                  <div>
                    <div className="text-[9px] sm:text-[10px] uppercase font-mono tracking-widest text-[#C9A050] mb-0.5 sm:mb-1">
                      {b.country}
                    </div>
                    <div className="font-serif-luxury text-sm sm:text-base font-bold text-white">
                      {b.city}
                    </div>
                    <div className="text-[11px] sm:text-xs text-zinc-400 mt-0.5 sm:mt-1 font-sans-modern">
                      {b.address}
                    </div>
                  </div>
                  <ChevronRight className={`w-4 h-4 transition-transform ${isSelected ? 'text-[#C9A050] translate-x-1' : 'text-zinc-600'}`} />
                </button>
              );
            })}
          </motion.div>

          {/* Right Column: Active Atelier Detail Showcase with Scroll-Replay Animation */}
          <motion.div 
            initial={{ opacity: 0, x: 20 }}
            whileInView={{ opacity: 1, x: 0 }}
            viewport={{ once: false, amount: 0.2 }}
            transition={{ duration: 0.55, delay: 0.15, ease: [0.16, 1, 0.3, 1] }}
            className="lg:col-span-7 bg-[#111115] border border-white/10 rounded-sm p-5 sm:p-10 relative overflow-hidden flex flex-col justify-between"
          >
            <div className="absolute top-0 right-0 w-64 h-64 bg-[#C9A050]/5 rounded-full blur-[80px] pointer-events-none" />

            <div>
              <div className="flex items-center justify-between border-b border-white/10 pb-3 sm:pb-4 mb-4 sm:mb-6">
                <div>
                  <span className="text-[10px] sm:text-xs uppercase tracking-widest text-[#C9A050] font-mono">Flagship Atelier</span>
                  <h3 className="font-serif-luxury text-xl sm:text-2xl font-bold text-white mt-1">
                    {selectedBoutique.city}
                  </h3>
                </div>
                <div className="text-right">
                  <span className="text-[10px] sm:text-[11px] text-zinc-500 uppercase tracking-widest block font-sans-modern">Private Salon</span>
                  <span className="text-[11px] sm:text-xs text-white font-mono">{selectedBoutique.country}</span>
                </div>
              </div>

              {/* Atelier Details */}
              <div className="space-y-3 sm:space-y-4 mb-5 sm:mb-8 text-xs sm:text-sm font-sans-modern text-zinc-300">
                <div className="flex items-start gap-2.5 sm:gap-3">
                  <MapPin className="w-3.5 h-3.5 sm:w-4 sm:h-4 text-[#C9A050] shrink-0 mt-0.5" />
                  <div>
                    <span className="text-zinc-500 block text-[10px] sm:text-[11px] uppercase tracking-wider">Address</span>
                    <span className="text-white font-medium">{selectedBoutique.address}, {selectedBoutique.country}</span>
                  </div>
                </div>

                <div className="flex items-start gap-2.5 sm:gap-3">
                  <Clock className="w-3.5 h-3.5 sm:w-4 sm:h-4 text-[#C9A050] shrink-0 mt-0.5" />
                  <div>
                    <span className="text-zinc-500 block text-[10px] sm:text-[11px] uppercase tracking-wider">Visiting Hours</span>
                    <span className="text-white font-medium">{selectedBoutique.hours}</span>
                  </div>
                </div>

                <div className="flex items-start gap-2.5 sm:gap-3">
                  <Phone className="w-3.5 h-3.5 sm:w-4 sm:h-4 text-[#C9A050] shrink-0 mt-0.5" />
                  <div>
                    <span className="text-zinc-500 block text-[10px] sm:text-[11px] uppercase tracking-wider">Direct Telephone Line</span>
                    <a href={`tel:${selectedBoutique.phone}`} className="text-white font-mono hover:text-[#D8B263] transition-colors">
                      {selectedBoutique.phone}
                    </a>
                  </div>
                </div>

                <div className="flex items-start gap-2.5 sm:gap-3">
                  <Mail className="w-3.5 h-3.5 sm:w-4 sm:h-4 text-[#C9A050] shrink-0 mt-0.5" />
                  <div>
                    <span className="text-zinc-500 block text-[10px] sm:text-[11px] uppercase tracking-wider">Atelier Director</span>
                    <span className="text-[#D8B263]">{selectedBoutique.featuredDirector}</span>
                  </div>
                </div>
              </div>

              {/* VIP Salon Amenity Notice */}
              <div className="p-3 sm:p-4 bg-white/5 border border-white/5 rounded-sm mb-5 sm:mb-8 text-[11px] sm:text-xs text-zinc-400 font-sans-modern leading-relaxed">
                Private appointments include hands-on access to prototype references, complimentary vintage champagne tasting, and one-on-one session with our master watchmaker.
              </div>
            </div>

            {/* Book Appointment Action */}
            <div className="pt-4 sm:pt-6 border-t border-white/10 flex flex-col sm:flex-row items-center justify-between gap-3 sm:gap-4">
              <div className="text-[11px] sm:text-xs text-zinc-400 font-sans-modern">
                Complimentary chauffeur service available within 30 miles.
              </div>
              <button
                onClick={() => onBookAppointment(selectedBoutique.city)}
                className="w-full sm:w-auto px-5 sm:px-6 py-3 sm:py-3.5 bg-gradient-to-r from-[#D8B263] to-[#B08A38] text-black font-sans-modern text-[11px] sm:text-xs font-semibold tracking-wider uppercase rounded-sm hover:brightness-110 transition-all flex items-center justify-center gap-2 cursor-pointer shadow-lg shadow-[#D8B263]/15 shrink-0"
              >
                <Calendar className="w-3.5 h-3.5 sm:w-4 sm:h-4" />
                <span>Book Atelier Appointment</span>
              </button>
            </div>

          </motion.div>

        </div>

      </div>
    </section>
  );
};
