import React, { useState } from 'react';
import { Shield, Sparkles, Layers, Cog, Award, Compass, ArrowRight } from 'lucide-react';
import { motion } from 'motion/react';
import { AnimatedCounter } from './AnimatedCounter';

interface ManufactureStoryProps {
  onExploreCollection: () => void;
}

export const ManufactureStory: React.FC<ManufactureStoryProps> = ({ onExploreCollection }) => {
  const [activeTab, setActiveTab] = useState<'calibre' | 'materials' | 'finishing'>('calibre');

  const chapters = [
    {
      id: 'calibre' as const,
      title: '01. In-House Calibre V-800',
      subtitle: 'The Architecture of Time',
      description: 'Conceived, developed, and fabricated entirely within our Geneva ateliers. The Calibre V-800 represents the pinnacle of contemporary skeleton horology. Over 290 distinct components are arrayed on multiple three-dimensional planes, allowing ambient light to penetrate the heart of the escapement.',
      specs: [
        { label: 'Escapement', value: 'One-Minute Flying Tourbillon' },
        { label: 'Frequency', value: '28,800 A/h (4 Hz)' },
        { label: 'Power Reserve', value: '115 Hours (Twin Barrels)' },
        { label: 'Jewels', value: '33 Synthetic Rubies' },
      ],
      image: '/frames/frame-030.jpg',
    },
    {
      id: 'materials' as const,
      title: '02. Material Alchemy',
      subtitle: 'The Fusion of Titanium & Sapphire',
      description: 'We reject conventional horological limits. By fusing Grade 5 aeronautical titanium with pure monocrystalline synthetic sapphire synthesized at over 2,000°C, Vauban timepieces achieve an unprecedented strength-to-weight ratio while maintaining exceptional scratch resistance.',
      specs: [
        { label: 'Crystal Hardness', value: '9 on Mohs Scale (Diamond is 10)' },
        { label: 'Case Density', value: '4.51 g/cm³ (45% lighter than steel)' },
        { label: 'Water Integrity', value: 'Hermetic Gasket up to 10 ATM' },
        { label: 'Shock Tolerance', value: '5,000 G Dynamic Impact Tested' },
      ],
      image: '/frames/frame-020.jpg',
    },
    {
      id: 'finishing' as const,
      title: '03. Hand Haute Finition',
      subtitle: 'The Human Touch of Geneva Artisans',
      description: 'While our geometries are calculated to micrometric tolerances, every internal bevel (anglage), circular graining (perlage), and mirror-black polish (poli noir) is executed by hand by master craftsmen with decades of generational mastery.',
      specs: [
        { label: 'Hand Chamfering', value: '45-Degree Diamond-Polished Bevels' },
        { label: 'Surface Treatment', value: 'Anthracite Ruthenium Electro-Plating' },
        { label: 'Inspection', value: 'Microscopic 30x Optical Quality Audit' },
        { label: 'Geneva Seal', value: 'Exceeding COSC Precision Standards' },
      ],
      image: '/frames/frame-001.jpg',
    },
  ];

  const current = chapters.find(c => c.id === activeTab) || chapters[0];

  // Helper to render numbers with scroll-replay animated counters
  const renderSpecValueWithCounter = (value: string) => {
    if (value.includes('115 Hours')) {
      return (
        <span>
          <AnimatedCounter target={115} suffix=" Hours" /> (Twin Barrels)
        </span>
      );
    }
    if (value.includes('28,800 A/h')) {
      return (
        <span>
          <AnimatedCounter target={28800} suffix=" A/h" /> (4 Hz)
        </span>
      );
    }
    if (value.includes('33 Synthetic Rubies')) {
      return (
        <span>
          <AnimatedCounter target={33} suffix=" Synthetic Rubies" />
        </span>
      );
    }
    if (value.includes('9 on Mohs Scale (Diamond is 10)')) {
      return (
        <span>
          <AnimatedCounter target={9} /> on Mohs Scale (Diamond is <AnimatedCounter target={10} />)
        </span>
      );
    }
    if (value.includes('10 ATM')) {
      return (
        <span>
          Hermetic Gasket up to <AnimatedCounter target={10} suffix=" ATM" /> (Tested)
        </span>
      );
    }
    if (value.includes('5,000 G')) {
      return (
        <span>
          <AnimatedCounter target={5000} suffix=" G" /> Dynamic Impact Tested
        </span>
      );
    }
    if (value.includes('45-Degree')) {
      return (
        <span>
          <AnimatedCounter target={45} suffix="°" /> Diamond-Polished Bevels
        </span>
      );
    }
    if (value.includes('30x')) {
      return (
        <span>
          Microscopic <AnimatedCounter target={30} suffix="x" /> Optical Quality Audit
        </span>
      );
    }
    return value;
  };

  return (
    <section id="manufacture" className="py-14 sm:py-32 bg-[#070708] border-t border-white/5 relative overflow-hidden">
      
      {/* Background ambient lighting */}
      <div className="absolute top-1/2 left-1/4 -translate-y-1/2 w-96 h-96 bg-[#C9A050]/5 rounded-full blur-[140px] pointer-events-none" />

      <div className="max-w-7xl mx-auto px-5 sm:px-8 lg:px-12 relative z-10">
        
        {/* Section Intro with Scroll-Replay Animation */}
        <motion.div 
          initial={{ opacity: 0, y: 24 }}
          whileInView={{ opacity: 1, y: 0 }}
          viewport={{ once: false, amount: 0.2 }}
          transition={{ duration: 0.55, ease: [0.16, 1, 0.3, 1] }}
          className="max-w-2xl mb-8 sm:mb-16"
        >
          <div className="flex items-center gap-2 text-[10px] sm:text-xs tracking-[0.25em] text-[#C9A050] uppercase font-sans-modern font-semibold mb-2 sm:mb-3">
            <span>Manufacture Provenance</span>
            <span className="w-8 h-[1px] bg-[#C9A050]/50" />
          </div>
          <h2 className="font-serif-luxury text-2xl sm:text-4xl lg:text-5xl font-bold text-white tracking-tight mb-3 sm:mb-4 text-balance">
            THE PHILOSOPHY OF HOROLOGICAL FUSION
          </h2>
          <p className="text-zinc-400 font-sans-modern text-xs sm:text-base leading-relaxed">
            Where aerospace-grade metallurgy merges with Swiss haute horlogerie tradition. Explore the engineering pillars behind every Vauban creation.
          </p>
        </motion.div>

        {/* Chapter Tabs with Scroll-Replay Animation */}
        <motion.div 
          initial={{ opacity: 0, y: 20 }}
          whileInView={{ opacity: 1, y: 0 }}
          viewport={{ once: false, amount: 0.2 }}
          transition={{ duration: 0.5, delay: 0.1, ease: [0.16, 1, 0.3, 1] }}
          className="grid grid-cols-1 md:grid-cols-3 gap-2.5 sm:gap-4 mb-8 sm:mb-12 border-b border-white/10 pb-4 sm:pb-6"
        >
          {chapters.map((ch) => (
            <button
              key={ch.id}
              onClick={() => setActiveTab(ch.id)}
              className={`text-left p-3 sm:p-4 rounded-sm transition-all cursor-pointer ${
                activeTab === ch.id
                  ? 'bg-white/10 border-l-2 border-[#C9A050]'
                  : 'hover:bg-white/5 text-zinc-400'
              }`}
            >
              <div className="text-[10px] sm:text-[11px] font-mono text-[#C9A050] mb-0.5 sm:mb-1">{ch.title}</div>
              <div className="font-serif-luxury text-sm sm:text-base font-semibold text-white">{ch.subtitle}</div>
            </button>
          ))}
        </motion.div>

        {/* Feature Split Showcase with Scroll-Replay Animation (Targeted Element) */}
        <motion.div 
          initial={{ opacity: 0, y: 26, scale: 0.99 }}
          whileInView={{ opacity: 1, y: 0, scale: 1 }}
          viewport={{ once: false, amount: 0.2 }}
          transition={{ duration: 0.6, delay: 0.15, ease: [0.16, 1, 0.3, 1] }}
          className="grid grid-cols-1 lg:grid-cols-12 gap-5 sm:gap-12 items-center bg-gradient-to-b from-[#0E0E12] to-[#08080A] border border-white/10 sm:border-white/5 rounded-xs sm:rounded-sm p-4 xs:p-6 sm:p-10 lg:p-12 shadow-xl"
        >
          
          {/* Visual Showcase: Appears directly below tabs on mobile for instant visual feedback, right column on desktop */}
          <div className="order-1 lg:order-2 lg:col-span-6 relative aspect-[16/10] sm:aspect-[16/10] max-h-56 xs:max-h-64 sm:max-h-none bg-gradient-to-b from-[#131318] to-[#0A0A0D] rounded-xs overflow-hidden border border-white/10 flex items-center justify-center p-3 xs:p-5 sm:p-6 shadow-inner">
            <div className="absolute inset-0 bg-radial from-[#C9A050]/15 via-transparent to-transparent pointer-events-none" />
            <img
              src={current.image}
              alt={current.subtitle}
              referrerPolicy="no-referrer"
              className="w-full h-full object-contain filter drop-shadow-[0_12px_24px_rgba(0,0,0,0.95)] transition-all duration-300"
            />
          </div>

          {/* Narrative & Technical Specs: Appears below image on mobile, left column on desktop */}
          <div className="order-2 lg:order-1 lg:col-span-6 space-y-3.5 sm:space-y-6">
            <div className="inline-flex items-center gap-1.5 px-2.5 py-0.5 sm:px-3 sm:py-1 bg-[#C9A050]/10 border border-[#C9A050]/30 text-[#D8B263] text-[9.5px] xs:text-[10px] sm:text-xs font-mono uppercase tracking-wider rounded-xs">
              <span className="w-1.5 h-1.5 rounded-full bg-[#D8B263] animate-pulse" />
              <span>{current.title}</span>
            </div>

            <h3 className="font-serif-luxury text-lg xs:text-xl sm:text-3xl font-bold text-white tracking-tight leading-snug">
              {current.subtitle}
            </h3>

            <p className="text-zinc-300 font-sans-modern text-xs xs:text-[13px] sm:text-base leading-relaxed">
              {current.description}
            </p>

            {/* Micro Technical Grid with Replaying Number Counters */}
            <div className="grid grid-cols-2 gap-2 xs:gap-3 pt-3 sm:pt-6 border-t border-white/10">
              {current.specs.map((s, idx) => (
                <div key={idx} className="bg-white/[0.04] hover:bg-white/[0.07] border border-white/5 p-2 xs:p-2.5 sm:p-3.5 rounded-xs transition-colors">
                  <div className="text-[8.5px] xs:text-[9.5px] sm:text-[10px] uppercase tracking-wider text-zinc-400 font-sans-modern mb-0.5 sm:mb-1">
                    {s.label}
                  </div>
                  <div className="text-[11.5px] xs:text-xs sm:text-sm font-semibold text-white font-sans-modern">
                    {renderSpecValueWithCounter(s.value)}
                  </div>
                </div>
              ))}
            </div>

            <div className="pt-1.5 sm:pt-4">
              <button
                onClick={onExploreCollection}
                className="inline-flex items-center gap-1.5 sm:gap-2 text-[11px] xs:text-xs font-sans-modern uppercase tracking-wider text-[#D8B263] hover:text-white transition-colors cursor-pointer group py-0.5"
              >
                <span>View Timepieces Featuring This Architecture</span>
                <ArrowRight className="w-3.5 h-3.5 sm:w-4 sm:h-4 transition-transform group-hover:translate-x-1" />
              </button>
            </div>
          </div>

        </motion.div>

      </div>
    </section>
  );
};

