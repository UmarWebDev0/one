import React from 'react';

export const WhatsAppButton: React.FC = () => {
  const cleanNumber = '923412683864';
  const whatsappUrl = `https://wa.me/${cleanNumber}?text=Hello%20VAUBAN%20Gen%C3%A8ve%2C%20I%20would%20like%20to%20inquire%20about%20your%20luxury%20timepieces.`;

  return (
    <aside
      aria-label="WhatsApp Concierge"
      className="fixed bottom-5 right-5 sm:bottom-6 sm:right-6 z-50 select-none"
    >
      <a
        href={whatsappUrl}
        target="_blank"
        rel="noopener noreferrer"
        aria-label="Chat on WhatsApp +92 3412683864"
        title="Chat on WhatsApp (+92 3412683864)"
        className="w-12 h-12 sm:w-14 sm:h-14 rounded-full bg-[#25D366] hover:bg-[#20ba59] text-white flex items-center justify-center shadow-[0_8px_25px_rgba(37,211,102,0.45)] hover:shadow-[0_12px_32px_rgba(37,211,102,0.65)] hover:scale-105 active:scale-95 transition-all duration-300 cursor-pointer"
      >
        <svg
          className="w-6 h-6 sm:w-7 sm:h-7 fill-current drop-shadow-sm"
          viewBox="0 0 24 24"
          xmlns="http://www.w3.org/2000/svg"
        >
          <path d="M12.04 2C6.58 2 2.13 6.45 2.13 11.91C2.13 13.66 2.59 15.36 3.45 16.86L2.05 22L7.3 20.62C8.75 21.41 10.38 21.83 12.04 21.83C17.5 21.83 21.95 17.38 21.95 11.92C21.95 9.27 20.92 6.78 19.05 4.91C17.18 3.04 14.69 2 12.04 2ZM12.04 3.67C14.25 3.67 16.31 4.53 17.87 6.09C19.42 7.65 20.28 9.72 20.28 11.92C20.28 16.46 16.58 20.16 12.04 20.16C10.64 20.16 9.27 19.8 8.08 19.09L7.8 18.92L4.69 19.74L5.52 16.71L5.33 16.41C4.55 15.17 4.14 13.56 4.14 11.91C4.14 7.37 7.84 3.67 12.04 3.67ZM8.63 7.37C8.44 7.37 8.24 7.38 8.06 7.74C7.88 8.1 7.38 8.57 7.38 9.53C7.38 10.49 8.08 11.41 8.18 11.55C8.28 11.68 9.53 13.63 11.48 14.47C13.11 15.17 13.44 14.97 14.04 14.91C14.64 14.85 15.96 14.13 16.23 13.37C16.5 12.61 16.5 11.95 16.42 11.82C16.34 11.68 16.14 11.61 15.84 11.46C15.54 11.31 14.08 10.59 13.81 10.49C13.54 10.39 13.34 10.34 13.14 10.64C12.94 10.94 12.38 11.61 12.21 11.81C12.04 12.01 11.87 12.03 11.57 11.88C11.27 11.73 10.31 11.42 9.17 10.4C8.28 9.61 7.68 8.63 7.51 8.33C7.34 8.03 7.49 7.87 7.64 7.72C7.78 7.58 7.95 7.35 8.1 7.18C8.25 7.01 8.3 6.89 8.4 6.69C8.5 6.49 8.45 6.32 8.38 6.17C8.3 6.02 7.73 4.57 7.49 3.99C7.25 3.42 7.02 3.5 6.84 3.49C6.67 3.48 6.47 3.48 6.27 3.48" />
        </svg>
      </a>
    </aside>
  );
};
