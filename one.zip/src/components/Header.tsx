import React, { useState, useEffect } from 'react';
import { Search, ShoppingBag, Heart, Menu, X, Clock, MapPin, User, ChevronRight } from 'lucide-react';

interface HeaderProps {
  cartCount: number;
  onOpenCart: () => void;
  onOpenSearch: () => void;
  onBookAppointment: () => void;
  onNavigateSection: (sectionId: string) => void;
}

export const Header: React.FC<HeaderProps> = ({
  cartCount,
  onOpenCart,
  onOpenSearch,
  onBookAppointment,
  onNavigateSection,
}) => {
  const [isScrolled, setIsScrolled] = useState(false);
  const [mobileMenuOpen, setMobileMenuOpen] = useState(false);

  useEffect(() => {
    const handleScroll = () => {
      setIsScrolled(window.scrollY > 40);
    };
    window.addEventListener('scroll', handleScroll, { passive: true });
    return () => window.removeEventListener('scroll', handleScroll);
  }, []);

  const navLinks = [
    { label: 'Timepieces', target: 'collections' },
    { label: 'Manufacture', target: 'manufacture' },
    { label: 'Story & Craft', target: 'story' },
    { label: 'Ateliers', target: 'ateliers' },
    { label: 'Concierge', target: 'concierge' },
  ];

  return (
    <div className="fixed top-0 inset-x-0 z-40 w-full transition-all duration-300">
      {/* Main Header: Follows Top Bar Contract */}
      <header
        className={`w-full transition-all duration-300 bg-black/95 backdrop-blur-md border-b border-white/10 ${
          isScrolled ? 'shadow-2xl py-3' : 'py-3.5'
        }`}
      >
        <div className="max-w-7xl mx-auto px-6 sm:px-8 lg:px-12 flex items-center justify-between gap-8">
          
          {/* Zone 1: Single text element Brand Wordmark */}
          <button
            onClick={() => {
              window.scrollTo({ top: 0, behavior: 'smooth' });
            }}
            className="flex flex-col sm:flex-row sm:items-baseline sm:gap-2 text-left cursor-pointer group whitespace-nowrap shrink-0 leading-none"
          >
            <span className="font-serif-luxury text-lg sm:text-2xl font-black tracking-[0.2em] text-white group-hover:text-[#D8B263] transition-colors">
              VAUBAN
            </span>
            <span className="text-[8.5px] sm:text-[10px] font-sans-modern tracking-[0.35em] uppercase text-[#D8B263] font-medium pt-0.5 sm:pt-0">
              GENÈVE
            </span>
          </button>

          {/* Zone 2: 4–5 Clean Single-Line Text Nav Links */}
          <nav className="hidden lg:flex items-center gap-8 text-xs font-sans-modern font-medium tracking-wider uppercase text-zinc-300">
            {navLinks.map((link) => (
              <button
                key={link.label}
                onClick={() => onNavigateSection(link.target)}
                className="hover:text-[#D8B263] transition-colors whitespace-nowrap shrink-0 cursor-pointer relative py-1 after:content-[''] after:absolute after:bottom-0 after:left-0 after:w-0 after:h-[1px] after:bg-[#C9A050] hover:after:w-full after:transition-all"
              >
                {link.label}
              </button>
            ))}
          </nav>

          {/* Zone 3: Interactive Affordances & Primary Action */}
          <div className="flex items-center gap-3 sm:gap-4 shrink-0">
            
            {/* Search Trigger */}
            <button
              onClick={onOpenSearch}
              className="p-2 text-zinc-400 hover:text-white transition-colors cursor-pointer rounded-full hover:bg-white/5"
              aria-label="Search Timepieces"
              title="Search Timepieces"
            >
              <Search className="w-4 h-4" />
            </button>

            {/* Shopping Bag / Cart */}
            <button
              onClick={onOpenCart}
              className="relative p-2 text-zinc-400 hover:text-white transition-colors cursor-pointer rounded-full hover:bg-white/5"
              aria-label="Shopping Bag"
              title="Shopping Bag"
            >
              <ShoppingBag className="w-4 h-4" />
              {cartCount > 0 && (
                <span className="absolute top-1 right-1 w-4 h-4 bg-[#D8B263] text-black text-[10px] font-bold rounded-full flex items-center justify-center tabular-nums">
                  {cartCount}
                </span>
              )}
            </button>

            {/* Primary Action Button */}
            <button
              onClick={onBookAppointment}
              className="hidden sm:inline-flex items-center gap-2 px-4 py-2 bg-white/5 hover:bg-white/10 text-[#D8B263] border border-[#C9A050]/40 text-xs font-sans-modern font-semibold tracking-wider uppercase rounded-sm transition-all whitespace-nowrap shrink-0 cursor-pointer"
            >
              <span>Private Viewing</span>
            </button>

            {/* Mobile Menu Trigger */}
            <button
              onClick={() => setMobileMenuOpen(!mobileMenuOpen)}
              className="lg:hidden p-2 text-zinc-400 hover:text-white transition-colors cursor-pointer"
              aria-label="Toggle Menu"
            >
              {mobileMenuOpen ? <X className="w-5 h-5" /> : <Menu className="w-5 h-5" />}
            </button>

          </div>

        </div>

        {/* Mobile Navigation Drawer */}
        {mobileMenuOpen && (
          <div className="lg:hidden bg-[#0A0A0D] border-b border-white/10 px-6 py-6 animate-in slide-in-from-top-2">
            <div className="flex flex-col gap-4 text-sm font-sans-modern tracking-wider uppercase text-zinc-300">
              {navLinks.map((link) => (
                <button
                  key={link.label}
                  onClick={() => {
                    onNavigateSection(link.target);
                    setMobileMenuOpen(false);
                  }}
                  className="flex items-center justify-between py-2 text-left hover:text-[#D8B263] border-b border-white/5 cursor-pointer"
                >
                  <span>{link.label}</span>
                  <ChevronRight className="w-4 h-4 text-zinc-600" />
                </button>
              ))}
              <div className="pt-2 flex flex-col gap-3">
                <button
                  onClick={() => {
                    onBookAppointment();
                    setMobileMenuOpen(false);
                  }}
                  className="w-full py-3 bg-[#D8B263] text-black text-xs font-semibold tracking-wider uppercase rounded-sm text-center"
                >
                  Book Private Atelier Viewing
                </button>
                <div className="text-center text-[11px] text-zinc-500 font-mono tracking-widest pt-2">
                  GENEVA · NEW YORK · TOKYO · LONDON · DUBAI
                </div>
              </div>
            </div>
          </div>
        )}
      </header>
    </div>
  );
};
