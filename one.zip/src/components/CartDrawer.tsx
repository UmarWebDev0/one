import React, { useState } from 'react';
import { Product } from '../data/products';
import { X, Trash2, ShieldCheck, Truck, ArrowRight, CheckCircle2 } from 'lucide-react';

export interface CartItem {
  product: Product;
  quantity: number;
  selectedStrap?: string;
  customEngraving?: string;
}

interface CartDrawerProps {
  isOpen: boolean;
  onClose: () => void;
  items: CartItem[];
  onUpdateQuantity: (productId: string, quantity: number) => void;
  onRemoveItem: (productId: string) => void;
  onClearCart: () => void;
}

export const CartDrawer: React.FC<CartDrawerProps> = ({
  isOpen,
  onClose,
  items,
  onUpdateQuantity,
  onRemoveItem,
  onClearCart,
}) => {
  const [isCheckingOut, setIsCheckingOut] = useState(false);
  const [orderConfirmed, setOrderConfirmed] = useState(false);
  const [orderNumber, setOrderNumber] = useState('');
  const [checkoutData, setCheckoutData] = useState({
    fullName: '',
    email: '',
    phone: '',
    deliveryAddress: '',
    city: '',
    postalCode: '',
    country: 'Switzerland',
    paymentMethod: 'Bank Wire Transfer (Insured)',
  });

  if (!isOpen) return null;

  const subtotal = items.reduce((acc, item) => acc + item.product.price * item.quantity, 0);
  const insuranceFee = 0; // Complimentary white glove insurance
  const total = subtotal + insuranceFee;

  const handlePlaceOrder = (e: React.FormEvent) => {
    e.preventDefault();
    const generatedOrder = `VB-${Math.floor(100000 + Math.random() * 900000)}`;
    setOrderNumber(generatedOrder);
    setOrderConfirmed(true);
    onClearCart();
  };

  return (
    <div className="fixed inset-0 z-50 overflow-hidden bg-black/80 backdrop-blur-sm animate-in fade-in duration-200">
      <div className="absolute inset-0" onClick={onClose} />

      <div className="absolute inset-y-0 right-0 max-w-full flex pl-10 pointer-events-auto">
        <div className="w-screen max-w-md bg-[#0C0C0F] border-l border-white/10 text-white flex flex-col justify-between shadow-2xl relative">
          
          {/* Header */}
          <div className="p-6 border-b border-white/10 flex items-center justify-between">
            <div className="flex items-center gap-2">
              <span className="font-serif-luxury text-lg font-bold">SHOPPING BAG</span>
              <span className="text-xs font-mono text-[#C9A050]">
                ({items.reduce((sum, item) => sum + item.quantity, 0)} {items.length === 1 ? 'PIECE' : 'PIECES'})
              </span>
            </div>
            <button
              onClick={onClose}
              className="p-2 text-zinc-400 hover:text-white rounded-full hover:bg-white/5 transition-colors cursor-pointer"
              aria-label="Close bag"
            >
              <X className="w-5 h-5" />
            </button>
          </div>

          {/* Content Area */}
          <div className="flex-1 overflow-y-auto p-6 space-y-6">
            {orderConfirmed ? (
              <div className="py-12 text-center space-y-4 animate-in fade-in">
                <div className="w-16 h-16 mx-auto rounded-full bg-[#C9A050]/20 border border-[#C9A050]/50 flex items-center justify-center text-[#D8B263]">
                  <CheckCircle2 className="w-9 h-9" />
                </div>
                <h3 className="font-serif-luxury text-xl font-bold">
                  ALLOCATION RESERVED
                </h3>
                <div className="text-xs font-mono text-[#C9A050] tracking-widest bg-white/5 py-2 px-3 inline-block rounded-sm">
                  ORDER REFERENCE #{orderNumber}
                </div>
                <p className="text-xs text-zinc-400 font-sans-modern leading-relaxed">
                  Your allocation has been securely recorded in our Geneva registry. A private client director will initiate contact to finalize armored courier dispatch and biometric verification.
                </p>
                <button
                  onClick={() => {
                    setOrderConfirmed(false);
                    setIsCheckingOut(false);
                    onClose();
                  }}
                  className="mt-4 px-6 py-2.5 bg-[#D8B263] text-black text-xs font-sans-modern font-semibold uppercase tracking-wider rounded-sm cursor-pointer"
                >
                  Return to Timepiece Collection
                </button>
              </div>
            ) : isCheckingOut ? (
              /* Checkout Form */
              <form onSubmit={handlePlaceOrder} className="space-y-4 text-xs font-sans-modern animate-in fade-in">
                <div className="border-b border-white/10 pb-3 mb-4">
                  <h4 className="font-serif-luxury text-base font-bold text-white">
                    CONFIDENTIAL DISPATCH DETAILS
                  </h4>
                  <p className="text-[11px] text-zinc-400 mt-0.5">
                    Armored courier delivery with sealed tamper-proof lockbox.
                  </p>
                </div>

                <div>
                  <label className="block text-[11px] uppercase tracking-wider text-zinc-400 mb-1">
                    Recipient Full Name *
                  </label>
                  <input
                    type="text"
                    required
                    value={checkoutData.fullName}
                    onChange={(e) => setCheckoutData({ ...checkoutData, fullName: e.target.value })}
                    placeholder="e.g. Lord Sterling Alexander"
                    className="w-full bg-[#141418] border border-white/10 rounded-sm px-3 py-2 text-white focus:outline-none focus:border-[#C9A050]"
                  />
                </div>

                <div className="grid grid-cols-2 gap-3">
                  <div>
                    <label className="block text-[11px] uppercase tracking-wider text-zinc-400 mb-1">
                      Email Address *
                    </label>
                    <input
                      type="email"
                      required
                      value={checkoutData.email}
                      onChange={(e) => setCheckoutData({ ...checkoutData, email: e.target.value })}
                      placeholder="client@luxury.com"
                      className="w-full bg-[#141418] border border-white/10 rounded-sm px-3 py-2 text-white focus:outline-none focus:border-[#C9A050]"
                    />
                  </div>
                  <div>
                    <label className="block text-[11px] uppercase tracking-wider text-zinc-400 mb-1">
                      Phone Number *
                    </label>
                    <input
                      type="tel"
                      required
                      value={checkoutData.phone}
                      onChange={(e) => setCheckoutData({ ...checkoutData, phone: e.target.value })}
                      placeholder="+92 3412683864"
                      className="w-full bg-[#141418] border border-white/10 rounded-sm px-3 py-2 text-white focus:outline-none focus:border-[#C9A050]"
                    />
                  </div>
                </div>

                <div>
                  <label className="block text-[11px] uppercase tracking-wider text-zinc-400 mb-1">
                    Armored Delivery Address *
                  </label>
                  <input
                    type="text"
                    required
                    value={checkoutData.deliveryAddress}
                    onChange={(e) => setCheckoutData({ ...checkoutData, deliveryAddress: e.target.value })}
                    placeholder="Residential or Private Office Address"
                    className="w-full bg-[#141418] border border-white/10 rounded-sm px-3 py-2 text-white focus:outline-none focus:border-[#C9A050]"
                  />
                </div>

                <div className="grid grid-cols-3 gap-2">
                  <div>
                    <label className="block text-[10px] uppercase tracking-wider text-zinc-400 mb-1">City *</label>
                    <input
                      type="text"
                      required
                      value={checkoutData.city}
                      onChange={(e) => setCheckoutData({ ...checkoutData, city: e.target.value })}
                      className="w-full bg-[#141418] border border-white/10 rounded-sm px-2.5 py-2 text-white focus:outline-none focus:border-[#C9A050]"
                    />
                  </div>
                  <div>
                    <label className="block text-[10px] uppercase tracking-wider text-zinc-400 mb-1">Postal Code *</label>
                    <input
                      type="text"
                      required
                      value={checkoutData.postalCode}
                      onChange={(e) => setCheckoutData({ ...checkoutData, postalCode: e.target.value })}
                      className="w-full bg-[#141418] border border-white/10 rounded-sm px-2.5 py-2 text-white focus:outline-none focus:border-[#C9A050]"
                    />
                  </div>
                  <div>
                    <label className="block text-[10px] uppercase tracking-wider text-zinc-400 mb-1">Country</label>
                    <input
                      type="text"
                      value={checkoutData.country}
                      onChange={(e) => setCheckoutData({ ...checkoutData, country: e.target.value })}
                      className="w-full bg-[#141418] border border-white/10 rounded-sm px-2.5 py-2 text-white focus:outline-none focus:border-[#C9A050]"
                    />
                  </div>
                </div>

                <div>
                  <label className="block text-[11px] uppercase tracking-wider text-zinc-400 mb-1">
                    Settlement Method
                  </label>
                  <select
                    value={checkoutData.paymentMethod}
                    onChange={(e) => setCheckoutData({ ...checkoutData, paymentMethod: e.target.value })}
                    className="w-full bg-[#141418] border border-white/10 rounded-sm px-3 py-2 text-white focus:outline-none focus:border-[#C9A050]"
                  >
                    <option value="Bank Wire Transfer (Insured)">Geneva Escrow Wire Transfer</option>
                    <option value="Private Banker Direct Invoice">Private Banker Direct Invoice</option>
                    <option value="Atelier Salon Settlement">Atelier Salon In-Person Settlement</option>
                  </select>
                </div>

                <div className="pt-2 flex gap-2">
                  <button
                    type="button"
                    onClick={() => setIsCheckingOut(false)}
                    className="flex-1 py-3 border border-white/20 text-zinc-300 uppercase tracking-wider font-semibold rounded-sm hover:bg-white/5 cursor-pointer"
                  >
                    Back to Bag
                  </button>
                  <button
                    type="submit"
                    className="flex-1 py-3 bg-[#D8B263] text-black uppercase tracking-wider font-semibold rounded-sm hover:brightness-110 cursor-pointer shadow-lg shadow-[#D8B263]/20"
                  >
                    Confirm Order
                  </button>
                </div>
              </form>
            ) : items.length === 0 ? (
              <div className="py-16 text-center space-y-3">
                <div className="text-zinc-600 font-serif-luxury text-4xl">∅</div>
                <h4 className="font-serif-luxury text-base text-zinc-300">YOUR SHOPPING BAG IS EMPTY</h4>
                <p className="text-xs text-zinc-500 max-w-xs mx-auto">
                  Select a timepiece from our Haute Horlogerie collections to request an allocation.
                </p>
              </div>
            ) : (
              <div className="space-y-4">
                {items.map((item) => (
                  <div
                    key={item.product.id}
                    className="p-4 bg-[#111115] border border-white/5 rounded-sm flex gap-4 items-center"
                  >
                    <div className="w-16 h-16 bg-[#16161C] p-1.5 rounded-sm shrink-0 flex items-center justify-center">
                      <img
                        src={item.product.image}
                        alt={item.product.name}
                        referrerPolicy="no-referrer"
                        className="w-full h-full object-contain"
                      />
                    </div>

                    <div className="flex-1 min-w-0">
                      <div className="text-[10px] font-mono text-zinc-500 uppercase">{item.product.reference}</div>
                      <h4 className="text-xs font-semibold text-white truncate font-serif-luxury">{item.product.name}</h4>
                      <div className="text-xs text-[#D8B263] font-serif-luxury font-bold tabular-nums mt-0.5">
                        ${item.product.price.toLocaleString()} USD
                      </div>
                      {item.selectedStrap && (
                        <div className="text-[10px] text-zinc-400 mt-0.5 truncate">
                          Strap: {item.selectedStrap}
                        </div>
                      )}
                      {item.customEngraving && (
                        <div className="text-[10px] text-[#C9A050] mt-0.5 truncate font-mono">
                          Engraved: "{item.customEngraving}"
                        </div>
                      )}
                    </div>

                    <button
                      onClick={() => onRemoveItem(item.product.id)}
                      className="p-2 text-zinc-500 hover:text-red-400 transition-colors cursor-pointer"
                      title="Remove item"
                    >
                      <Trash2 className="w-4 h-4" />
                    </button>
                  </div>
                ))}
              </div>
            )}
          </div>

          {/* Footer & Checkout Trigger */}
          {items.length > 0 && !isCheckingOut && !orderConfirmed && (
            <div className="p-6 border-t border-white/10 bg-[#0A0A0D] space-y-4">
              <div className="space-y-2 text-xs font-sans-modern">
                <div className="flex justify-between text-zinc-400">
                  <span>Subtotal</span>
                  <span className="text-white font-medium tabular-nums">${subtotal.toLocaleString()} USD</span>
                </div>
                <div className="flex justify-between text-zinc-400">
                  <span>Insured Armored Courier</span>
                  <span className="text-[#C9A050] font-medium uppercase tracking-wider text-[11px]">Complimentary</span>
                </div>
                <div className="flex justify-between text-base font-serif-luxury font-bold text-white pt-2 border-t border-white/5">
                  <span>Total Amount</span>
                  <span className="tabular-nums">${total.toLocaleString()} USD</span>
                </div>
              </div>

              <button
                onClick={() => setIsCheckingOut(true)}
                className="w-full py-3.5 bg-gradient-to-r from-[#D8B263] to-[#B08A38] text-black font-sans-modern text-xs font-semibold tracking-wider uppercase rounded-sm hover:brightness-110 transition-all flex items-center justify-center gap-2 cursor-pointer shadow-lg shadow-[#D8B263]/15"
              >
                <span>Proceed to Secure Allocation</span>
                <ArrowRight className="w-4 h-4" />
              </button>

              <div className="flex items-center justify-center gap-3 text-[10px] text-zinc-500 font-sans-modern">
                <div className="flex items-center gap-1">
                  <ShieldCheck className="w-3.5 h-3.5 text-[#C9A050]" />
                  <span>Escrow Protection</span>
                </div>
                <span>·</span>
                <div className="flex items-center gap-1">
                  <Truck className="w-3.5 h-3.5 text-[#C9A050]" />
                  <span>Armored Dispatch</span>
                </div>
              </div>
            </div>
          )}

        </div>
      </div>
    </div>
  );
};
