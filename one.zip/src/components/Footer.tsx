import React, { useState } from 'react';
import { ArrowRight, Check, Instagram, Twitter, Youtube, Linkedin } from 'lucide-react';

export const Footer: React.FC = () => {
  const [email, setEmail] = useState('');
  const [subscribed, setSubscribed] = useState(false);
  const [currency, setCurrency] = useState('USD');

  const handleSubscribe = (e: React.FormEvent) => {
    e.preventDefault();
    if (email) {
      setSubscribed(true);
    }
  };

  return (
    <footer className="bg-[#050506] border-t border-white/10 text-white font-sans-modern pt-10 pb-8 sm:pt-14 sm:pb-10 md:pt-20 md:pb-12">
      <div className="max-w-7xl mx-auto px-4 sm:px-6 md:px-8 lg:px-12">
        
        {/* Top Tier: Brand Wordmark, Social Media & Collector Dispatch Signup */}
        <div className="grid grid-cols-1 lg:grid-cols-12 gap-6 sm:gap-8 lg:gap-12 pb-8 sm:pb-12 md:pb-16 border-b border-white/10">
          
          <div className="lg:col-span-6 space-y-3 sm:space-y-3.5 md:space-y-4">
            <div className="flex items-baseline gap-2">
              <span className="font-serif-luxury text-xl sm:text-2xl font-black tracking-[0.2em] text-white">
                VAUBAN
              </span>
              <span className="text-[9.5px] sm:text-[10px] tracking-[0.3em] uppercase text-[#C9A050] font-medium font-mono">
                GENÈVE
              </span>
            </div>
            <p className="text-xs sm:text-sm text-zinc-400 max-w-md leading-relaxed">
              Swiss Haute Horlogerie house founded on the architectural fusion of aerospace titanium, monocrystalline sapphire, and openworked tourbillon calibres.
            </p>
            <div className="text-[10px] sm:text-xs text-zinc-500 font-mono tracking-wider pt-0.5 sm:pt-2 leading-relaxed">
              MANUFACTURE VAUBAN SA · RUE DU RHÔNE 40 · 1204 GENÈVE · SUISSE
            </div>

            {/* Social Media Channels: Small, elegant, properly aligned */}
            <div className="flex items-center gap-2 pt-1 sm:pt-2">
              <span className="text-[9.5px] sm:text-[10px] uppercase font-mono tracking-widest text-zinc-500 mr-0.5 hidden xs:inline-block">
                Salons:
              </span>
              <a
                href="https://www.instagram.com/usman_devhub?cplk=a3dwOWRqaDNzdW9n"
                target="_blank"
                rel="noopener noreferrer"
                aria-label="VAUBAN on Instagram (@usman_devhub)"
                className="w-7 h-7 sm:w-8 sm:h-8 rounded-xs border border-white/10 hover:border-[#D8B263]/50 bg-white/[0.03] hover:bg-white/10 text-zinc-400 hover:text-[#D8B263] flex items-center justify-center transition-all cursor-pointer"
              >
                <Instagram className="w-3.5 h-3.5" />
              </a>
              <a
                href="https://twitter.com"
                target="_blank"
                rel="noopener noreferrer"
                aria-label="VAUBAN on X"
                className="w-7 h-7 sm:w-8 sm:h-8 rounded-xs border border-white/10 hover:border-[#D8B263]/50 bg-white/[0.03] hover:bg-white/10 text-zinc-400 hover:text-[#D8B263] flex items-center justify-center transition-all cursor-pointer"
              >
                <Twitter className="w-3.5 h-3.5" />
              </a>
              <a
                href="https://youtube.com"
                target="_blank"
                rel="noopener noreferrer"
                aria-label="VAUBAN on YouTube"
                className="w-7 h-7 sm:w-8 sm:h-8 rounded-xs border border-white/10 hover:border-[#D8B263]/50 bg-white/[0.03] hover:bg-white/10 text-zinc-400 hover:text-[#D8B263] flex items-center justify-center transition-all cursor-pointer"
              >
                <Youtube className="w-3.5 h-3.5" />
              </a>
              <a
                href="https://linkedin.com"
                target="_blank"
                rel="noopener noreferrer"
                aria-label="VAUBAN on LinkedIn"
                className="w-7 h-7 sm:w-8 sm:h-8 rounded-xs border border-white/10 hover:border-[#D8B263]/50 bg-white/[0.03] hover:bg-white/10 text-zinc-400 hover:text-[#D8B263] flex items-center justify-center transition-all cursor-pointer"
              >
                <Linkedin className="w-3.5 h-3.5" />
              </a>
            </div>
          </div>

          <div className="lg:col-span-6">
            <h4 className="font-serif-luxury text-xs sm:text-base font-bold text-white mb-1.5 sm:mb-2 tracking-wide uppercase">
              PRIVATE COLLECTOR ALLOCATION BULLETIN
            </h4>
            <p className="text-[11px] sm:text-xs text-zinc-400 mb-2.5 sm:mb-4 leading-relaxed">
              Subscribe to receive confidential invitations to limited series allocations, SIHH previews, and salon openings prior to public release.
            </p>

            {subscribed ? (
              <div className="p-2.5 sm:p-3 bg-white/5 border border-[#C9A050]/40 rounded-sm text-[11px] sm:text-xs text-[#D8B263] flex items-center gap-2">
                <Check className="w-4 h-4 shrink-0" />
                <span>You have been entered into the private collector registry.</span>
              </div>
            ) : (
              <form onSubmit={handleSubscribe} className="flex gap-2 w-full max-w-md">
                <input
                  type="email"
                  required
                  value={email}
                  onChange={(e) => setEmail(e.target.value)}
                  placeholder="Enter your email address..."
                  className="flex-1 min-w-0 bg-[#111115] border border-white/10 rounded-sm px-3 py-2 sm:px-4 sm:py-2.5 text-[11px] sm:text-xs text-white placeholder-zinc-600 focus:outline-none focus:border-[#C9A050]"
                />
                {/* 1. BUTTON OPTIMIZATION: Compact, elegant, perfectly fitted on mobile while preserving desktop size */}
                <button
                  type="submit"
                  className="px-3.5 py-2 sm:px-5 sm:py-2.5 bg-[#D8B263] text-black text-[10.5px] sm:text-xs font-semibold uppercase tracking-wider rounded-sm hover:brightness-110 active:scale-[0.98] transition-all flex items-center justify-center gap-1 sm:gap-1.5 cursor-pointer shrink-0 whitespace-nowrap"
                >
                  <span>Request Entry</span>
                  <ArrowRight className="w-3 h-3 sm:w-3.5 sm:h-3.5 shrink-0" />
                </button>
              </form>
            )}
          </div>

        </div>

        {/* Middle Tier: Structured Navigation Columns */}
        <div className="grid grid-cols-2 md:grid-cols-4 gap-x-4 gap-y-7 sm:gap-8 py-8 sm:py-12 md:py-16 border-b border-white/10 text-xs">
          
          <div>
            <h5 className="font-serif-luxury text-xs sm:text-xs md:text-sm font-bold text-[#E5C178] sm:text-white mb-2.5 sm:mb-3 md:mb-4 tracking-wider uppercase">
              Timepieces
            </h5>
            <ul className="space-y-1.5 sm:space-y-2 md:space-y-2.5 text-[11px] md:text-xs text-zinc-400">
              <li><a href="#collections" className="block py-0.5 hover:text-white transition-colors truncate">Monolith Skeleton Tourbillon</a></li>
              <li><a href="#collections" className="block py-0.5 hover:text-white transition-colors truncate">Obsidian Ceramic Chronograph</a></li>
              <li><a href="#collections" className="block py-0.5 hover:text-white transition-colors truncate">Aurelia King Gold Royal</a></li>
              <li><a href="#collections" className="block py-0.5 hover:text-white transition-colors truncate">Vapour Carbon Aerofusion</a></li>
              <li><a href="#collections" className="block py-0.5 hover:text-white transition-colors truncate">Spectra Synthetic Sapphire</a></li>
            </ul>
          </div>

          <div>
            <h5 className="font-serif-luxury text-xs sm:text-xs md:text-sm font-bold text-[#E5C178] sm:text-white mb-2.5 sm:mb-3 md:mb-4 tracking-wider uppercase">
              Manufacture
            </h5>
            <ul className="space-y-1.5 sm:space-y-2 md:space-y-2.5 text-[11px] md:text-xs text-zinc-400">
              <li><a href="#manufacture" className="block py-0.5 hover:text-white transition-colors truncate">In-House Calibre V-800</a></li>
              <li><a href="#manufacture" className="block py-0.5 hover:text-white transition-colors truncate">Material Metallurgy</a></li>
              <li><a href="#manufacture" className="block py-0.5 hover:text-white transition-colors truncate">Hand-Bevelled Anglage</a></li>
              <li><a href="#manufacture" className="block py-0.5 hover:text-white transition-colors truncate">Geneva Chronometry Standards</a></li>
              <li><a href="#manufacture" className="block py-0.5 hover:text-white transition-colors truncate">Interchangeable Strap System</a></li>
            </ul>
          </div>

          <div>
            <h5 className="font-serif-luxury text-xs sm:text-xs md:text-sm font-bold text-[#E5C178] sm:text-white mb-2.5 sm:mb-3 md:mb-4 tracking-wider uppercase">
              Client Salons
            </h5>
            <ul className="space-y-1.5 sm:space-y-2 md:space-y-2.5 text-[11px] md:text-xs text-zinc-400">
              <li><a href="#ateliers" className="block py-0.5 hover:text-white transition-colors truncate">Geneva Atelier Flagship</a></li>
              <li><a href="#ateliers" className="block py-0.5 hover:text-white transition-colors truncate">New York Madison Salon</a></li>
              <li><a href="#ateliers" className="block py-0.5 hover:text-white transition-colors truncate">Tokyo Ginza Sanctuary</a></li>
              <li><a href="#ateliers" className="block py-0.5 hover:text-white transition-colors truncate">London New Bond Suite</a></li>
              <li><a href="#ateliers" className="block py-0.5 hover:text-white transition-colors truncate">Dubai Mall Private Salon</a></li>
            </ul>
          </div>

          <div>
            <h5 className="font-serif-luxury text-xs sm:text-xs md:text-sm font-bold text-[#E5C178] sm:text-white mb-2.5 sm:mb-3 md:mb-4 tracking-wider uppercase">
              Concierge Services
            </h5>
            <ul className="space-y-1.5 sm:space-y-2 md:space-y-2.5 text-[11px] md:text-xs text-zinc-400">
              <li><a href="#concierge" className="block py-0.5 hover:text-white transition-colors truncate">Armored Courier Transport</a></li>
              <li><a href="#concierge" className="block py-0.5 hover:text-white transition-colors truncate">5-Year International Warranty</a></li>
              <li><a href="#concierge" className="block py-0.5 hover:text-white transition-colors truncate">Bespoke Engraving & Rotor</a></li>
              <li><a href="#concierge" className="block py-0.5 hover:text-white transition-colors truncate">Certificate of Origin</a></li>
              <li><a href="#concierge" className="block py-0.5 hover:text-white transition-colors truncate">Watchmaker Recalibration</a></li>
            </ul>
          </div>

        </div>

        {/* Bottom Tier: Legal, Currency & Copyright */}
        <div className="pt-6 sm:pt-7 md:pt-8 flex flex-col md:flex-row items-center justify-between gap-4 sm:gap-5 md:gap-6 text-[10px] sm:text-[11px] text-zinc-500">
          
          <div className="flex flex-wrap items-center justify-center md:justify-start gap-x-3 gap-y-1.5 text-center md:text-left leading-relaxed">
            <span className="text-zinc-400">© 2026 VAUBAN GENÈVE SA. ALL RIGHTS RESERVED.</span>
            <span className="hidden sm:inline">·</span>
            <span className="hover:text-zinc-300 cursor-pointer transition-colors">PRIVACY POLICY</span>
            <span>·</span>
            <span className="hover:text-zinc-300 cursor-pointer transition-colors">TERMS OF ALLOCATION</span>
            <span>·</span>
            <span className="hover:text-zinc-300 cursor-pointer transition-colors">AUTHENTICITY REGISTRY</span>
          </div>

          <div className="flex items-center gap-2.5 sm:gap-3 shrink-0">
            <span className="uppercase tracking-widest text-[9.5px] sm:text-[10px] text-zinc-400">Currency:</span>
            <select
              value={currency}
              onChange={(e) => setCurrency(e.target.value)}
              className="bg-[#111115] border border-white/10 rounded-sm px-2 py-1 text-white text-[11px] sm:text-xs focus:outline-none focus:border-[#C9A050] cursor-pointer"
            >
              <option value="USD">USD ($)</option>
              <option value="CHF">CHF (Fr.)</option>
              <option value="EUR">EUR (€)</option>
              <option value="GBP">GBP (£)</option>
              <option value="JPY">JPY (¥)</option>
            </select>
          </div>

        </div>

      </div>
    </footer>
  );
};
