import React, { useEffect, useRef, useState, useCallback } from 'react';
import { HERO_FRAMES, TOTAL_FRAMES } from '../data/frames';

interface HeroSequenceProps {
  onExploreProduct?: (productId: string) => void;
  onBookAppointment?: () => void;
}

function easeInOutCubic(x: number): number {
  return x < 0.5 ? 4 * x * x * x : 1 - Math.pow(-2 * x + 2, 3) / 2;
}

function computeStageStyle(
  progress: number,
  inStart: number,
  inEnd: number,
  outStart: number,
  outEnd: number,
  side: 'left' | 'right'
) {
  if (progress < inStart - 0.04 || progress > outEnd + 0.04) {
    return {
      opacity: 0,
      transform: `translate3d(${side === 'left' ? '-60px' : '60px'}, 0, 0)`,
      visibility: 'hidden' as const,
      pointerEvents: 'none' as const,
    };
  }

  let opacity = 0;
  let tx = 0;

  if (progress <= inStart) {
    opacity = inStart === 0 ? 1 : 0;
    tx = inStart === 0 ? 0 : (side === 'left' ? -60 : 60);
  } else if (progress < inEnd) {
    const raw = (progress - inStart) / (inEnd - inStart);
    const ease = easeInOutCubic(Math.min(1, Math.max(0, raw)));
    opacity = ease;
    const offset = side === 'left' ? -60 : 60;
    tx = offset * (1 - ease);
  } else if (progress <= outStart) {
    opacity = 1;
    tx = 0;
  } else if (progress < outEnd) {
    const raw = (progress - outStart) / (outEnd - outStart);
    const ease = easeInOutCubic(Math.min(1, Math.max(0, raw)));
    opacity = 1 - ease;
    const exitOffset = side === 'left' ? -50 : 50;
    tx = exitOffset * ease;
  } else {
    opacity = 0;
    tx = side === 'left' ? -50 : 50;
  }

  const isVisible = opacity > 0.005;

  return {
    opacity: Number(opacity.toFixed(3)),
    transform: `translate3d(${tx.toFixed(1)}px, 0, 0)`,
    visibility: (isVisible ? 'visible' : 'hidden') as 'visible' | 'hidden',
    pointerEvents: (opacity > 0.6 ? 'auto' : 'none') as 'auto' | 'none',
    transition: 'none',
    willChange: 'transform, opacity',
  };
}

// Continuous mobile cinematic scroll animation:
// Animates continuously as long as the user scrolls, through the entire depth of the Hero section.
// Stage 1 is centered at scroll 0, gliding smoothly as user scrolls.
// Stages 2, 3, 4 sequentially glide through the lower area of the Hero background.
// Stage 4 remains visible and active all the way down to the bottom (progress 1.00).
function computeMobileStageStyle(
  progress: number,
  start: number,
  end: number,
  isFirst: boolean = false,
  isLast: boolean = false
) {
  if (progress < start && !isFirst) {
    return {
      opacity: 0,
      transform: 'translate3d(0, 24px, 0)',
      visibility: 'hidden' as const,
      pointerEvents: 'none' as const,
      transition: 'none',
      willChange: 'transform, opacity',
    };
  }
  if (progress > end && !isLast) {
    return {
      opacity: 0,
      transform: 'translate3d(0, -24px, 0)',
      visibility: 'hidden' as const,
      pointerEvents: 'none' as const,
      transition: 'none',
      willChange: 'transform, opacity',
    };
  }

  const clamped = Math.min(end, Math.max(start, progress));
  const t = (clamped - start) / (end - start);

  // Continuous parallax glide during scroll:
  let ty: number;
  if (isFirst) {
    ty = -24 * easeInOutCubic(t);
  } else if (isLast) {
    ty = 24 * (1 - easeInOutCubic(t));
  } else {
    ty = 24 - 48 * t;
  }

  // Opacity curve ensuring seamless transition between headings:
  let opacity: number;
  if (isFirst) {
    if (t < 0.55) {
      opacity = 1;
    } else {
      const fadeOut = (t - 0.55) / 0.45;
      opacity = 1 - easeInOutCubic(fadeOut);
    }
  } else if (isLast) {
    if (t < 0.35) {
      opacity = easeInOutCubic(t / 0.35);
    } else {
      opacity = 1;
    }
  } else {
    if (t < 0.30) {
      opacity = easeInOutCubic(t / 0.30);
    } else if (t <= 0.70) {
      opacity = 1;
    } else {
      opacity = 1 - easeInOutCubic((t - 0.70) / 0.30);
    }
  }

  const isVisible = opacity > 0.005;

  return {
    opacity: Number(opacity.toFixed(3)),
    transform: `translate3d(0, ${ty.toFixed(1)}px, 0)`,
    visibility: (isVisible ? 'visible' : 'hidden') as 'visible' | 'hidden',
    pointerEvents: (opacity > 0.6 ? 'auto' : 'none') as 'auto' | 'none',
    transition: 'none',
    willChange: 'transform, opacity',
  };
}

export const HeroSequence: React.FC<HeroSequenceProps> = () => {
  const containerRef = useRef<HTMLDivElement>(null);
  const canvasRef = useRef<HTMLCanvasElement>(null);

  // Cached images
  const imagesRef = useRef<(HTMLImageElement | null)[]>(new Array(TOTAL_FRAMES).fill(null));
  const loadedSetRef = useRef<Set<number>>(new Set());
  const [isInitialReady, setIsInitialReady] = useState(false);
  const [smoothProgress, setSmoothProgress] = useState(0);

  // Animation values stored in refs for 60fps/120fps interpolation
  const targetFrameRef = useRef<number>(0);
  const currentRenderedFrameRef = useRef<number>(0);
  const targetProgressRef = useRef<number>(0);
  const smoothProgressRef = useRef<number>(0);
  const rafIdRef = useRef<number | null>(null);

  // Desktop Stage Styles (Left, Right, Left, Right - Final & Untouched)
  const stage1Style = computeStageStyle(smoothProgress, 0.00, 0.00, 0.16, 0.25, 'left');
  const stage2Style = computeStageStyle(smoothProgress, 0.22, 0.30, 0.44, 0.52, 'right');
  const stage3Style = computeStageStyle(smoothProgress, 0.48, 0.56, 0.70, 0.78, 'left');
  const stage4Style = computeStageStyle(smoothProgress, 0.74, 0.82, 0.95, 1.00, 'right');

  // Mobile Cinematic Stages (Pure Text Directly Over Image):
  // Continuously active across the entire scroll from top (0.00) down to the very bottom (1.00)
  const mobileStage1Style = computeMobileStageStyle(smoothProgress, 0.00, 0.28, true, false);
  const mobileStage2Style = computeMobileStageStyle(smoothProgress, 0.22, 0.52, false, false);
  const mobileStage3Style = computeMobileStageStyle(smoothProgress, 0.46, 0.76, false, false);
  const mobileStage4Style = computeMobileStageStyle(smoothProgress, 0.70, 1.00, false, true);

  // Load a single frame by index, trying local WebP first, then local JPG, then direct CDN fallback
  const loadFrame = useCallback((index: number): Promise<HTMLImageElement> => {
    return new Promise((resolve) => {
      if (imagesRef.current[index]) {
        resolve(imagesRef.current[index]!);
        return;
      }
      const frameData = HERO_FRAMES[index];
      if (!frameData) return;

      const img = new Image();
      img.crossOrigin = 'anonymous';
      img.decoding = 'async';

      img.onload = () => {
        imagesRef.current[index] = img;
        loadedSetRef.current.add(index);
        if (index === 0) {
          setIsInitialReady(true);
        }
        resolve(img);
      };

      img.onerror = () => {
        if (img.src.endsWith('.webp') && frameData.jpgFallbackUrl) {
          // Fallback to local JPG if WebP fails
          img.src = frameData.jpgFallbackUrl;
        } else if (img.src !== frameData.directUrl && frameData.directUrl) {
          // Fallback to remote CDN if local fails
          img.src = frameData.directUrl;
        } else {
          resolve(img);
        }
      };

      img.src = frameData.localUrl || frameData.jpgFallbackUrl || frameData.directUrl;
    });
  }, []);

  // Preloading sequence: frame 0 immediately, then progressive preloading
  useEffect(() => {
    let isCancelled = false;

    async function initPreload() {
      await loadFrame(0);
      setIsInitialReady(true);

      if (isCancelled) return;

      const allFrames = [];
      for (let i = 1; i < TOTAL_FRAMES; i++) {
        allFrames.push(loadFrame(i));
      }
      await Promise.allSettled(allFrames);
    }

    initPreload();
    return () => {
      isCancelled = true;
    };
  }, [loadFrame]);

  // Full-screen (100vw × 100vh) Canvas Rendering
  const renderFrameToCanvas = useCallback((frameIdx: number) => {
    const canvas = canvasRef.current;
    if (!canvas) return;
    const ctx = canvas.getContext('2d', { alpha: false });
    if (!ctx) return;

    let imgToDraw: HTMLImageElement | null = imagesRef.current[frameIdx];
    if (!imgToDraw || !imgToDraw.complete || imgToDraw.naturalWidth === 0) {
      let closestIdx = -1;
      let minDistance = Infinity;
      for (const loadedIdx of loadedSetRef.current) {
        const dist = Math.abs(loadedIdx - frameIdx);
        if (dist < minDistance) {
          minDistance = dist;
          closestIdx = loadedIdx;
        }
      }
      if (closestIdx !== -1) {
        imgToDraw = imagesRef.current[closestIdx];
      }
    }

    if (!imgToDraw || !imgToDraw.complete || imgToDraw.naturalWidth === 0) return;

    const canvasWidth = canvas.width;
    const canvasHeight = canvas.height;
    const imgWidth = imgToDraw.naturalWidth;
    const imgHeight = imgToDraw.naturalHeight;

    // Full screen cover calculation
    const hRatio = canvasWidth / imgWidth;
    const vRatio = canvasHeight / imgHeight;
    const ratio = Math.max(hRatio, vRatio);

    const drawWidth = imgWidth * ratio;
    const drawHeight = imgHeight * ratio;
    const offsetX = (canvasWidth - drawWidth) / 2;
    const offsetY = (canvasHeight - drawHeight) / 2;

    ctx.drawImage(imgToDraw, 0, 0, imgWidth, imgHeight, offsetX, offsetY, drawWidth, drawHeight);
  }, []);

  // Responsive Canvas Resize
  const handleResize = useCallback(() => {
    const canvas = canvasRef.current;
    if (!canvas) return;

    const dpr = Math.min(window.devicePixelRatio || 1, 2);
    const targetWidth = Math.floor(window.innerWidth * dpr);
    const targetHeight = Math.floor(window.innerHeight * dpr);

    if (canvas.width !== targetWidth || canvas.height !== targetHeight) {
      canvas.width = targetWidth;
      canvas.height = targetHeight;
      renderFrameToCanvas(Math.round(currentRenderedFrameRef.current));
    }
  }, [renderFrameToCanvas]);

  useEffect(() => {
    handleResize();
    window.addEventListener('resize', handleResize, { passive: true });
    return () => window.removeEventListener('resize', handleResize);
  }, [handleResize]);

  // Initial draw
  useEffect(() => {
    if (isInitialReady) {
      handleResize();
      renderFrameToCanvas(0);
    }
  }, [isInitialReady, handleResize, renderFrameToCanvas]);

  // 60fps/120fps Smooth Animation Loop: Synchronizes frames and text position
  useEffect(() => {
    let lastRenderedIndex = -1;

    const renderLoop = () => {
      // 1. Smooth frame interpolation
      const target = targetFrameRef.current;
      const current = currentRenderedFrameRef.current;
      const diff = target - current;

      if (Math.abs(diff) > 0.005) {
        currentRenderedFrameRef.current = current + diff * 0.22;
      } else {
        currentRenderedFrameRef.current = target;
      }

      const integerIndex = Math.min(
        TOTAL_FRAMES - 1,
        Math.max(0, Math.round(currentRenderedFrameRef.current))
      );

      if (integerIndex !== lastRenderedIndex) {
        lastRenderedIndex = integerIndex;
        renderFrameToCanvas(integerIndex);
      }

      // 2. Smooth progress interpolation for text transitions
      const pTarget = targetProgressRef.current;
      const pCurrent = smoothProgressRef.current;
      const pDiff = pTarget - pCurrent;

      if (Math.abs(pDiff) > 0.0003) {
        smoothProgressRef.current = pCurrent + pDiff * 0.18;
        setSmoothProgress(smoothProgressRef.current);
      } else if (pDiff !== 0) {
        smoothProgressRef.current = pTarget;
        setSmoothProgress(pTarget);
      }

      rafIdRef.current = requestAnimationFrame(renderLoop);
    };

    rafIdRef.current = requestAnimationFrame(renderLoop);
    return () => {
      if (rafIdRef.current) cancelAnimationFrame(rafIdRef.current);
    };
  }, [renderFrameToCanvas]);

  // Scroll Listener
  useEffect(() => {
    const onScroll = () => {
      const container = containerRef.current;
      if (!container) return;

      const rect = container.getBoundingClientRect();
      const totalScrollable = rect.height - window.innerHeight;
      if (totalScrollable <= 0) return;

      const scrolled = -rect.top;
      const rawProgress = scrolled / totalScrollable;
      const clampedProgress = Math.min(1, Math.max(0, rawProgress));

      targetProgressRef.current = clampedProgress;
      targetFrameRef.current = clampedProgress * (TOTAL_FRAMES - 1);
    };

    window.addEventListener('scroll', onScroll, { passive: true });
    onScroll();
    return () => window.removeEventListener('scroll', onScroll);
  }, []);

  return (
    <section
      ref={containerRef}
      className="relative w-full h-[320vh] md:h-[450vh] bg-black text-white"
      id="hero-experience"
    >
      {/* Sticky Fullscreen 100% Viewport */}
      <div className="sticky top-0 w-full max-w-full h-screen h-[100dvh] overflow-hidden flex flex-col justify-between">
        
        {/* Full-Screen Edge-to-Edge Canvas */}
        <canvas
          ref={canvasRef}
          className="absolute inset-0 w-full h-full block z-0"
          style={{ width: '100%', height: '100%' }}
        />

        {/* Subtle Top & Bottom Cinematic Vignettes */}
        <div className="absolute top-0 inset-x-0 h-32 pointer-events-none bg-gradient-to-b from-black/70 via-black/30 to-transparent z-10" />
        <div className="absolute bottom-0 inset-x-0 h-32 pointer-events-none bg-gradient-to-t from-black/80 via-black/40 to-transparent z-10" />

        {/* ==================== 1. MOBILE HERO TYPOGRAPHY (PURE TEXT OVER IMAGE, NO BOXES/CARDS) ==================== */}
        <div className="block md:hidden pointer-events-none">
          
          {/* HEADING 1 - POSITIONED NEATLY BELOW HEADER ON MOBILE SCREEN */}
          <div
            style={mobileStage1Style}
            className="absolute inset-x-0 top-0 z-20 flex flex-col items-center pt-20 xs:pt-24 select-none w-full"
          >
            <div className="relative flex flex-col items-center text-center w-full select-none pointer-events-auto">
              {/* Edge-to-edge full width dark background overlay spanning 100% with ZERO left and right side gaps */}
              <div
                aria-hidden="true"
                className="absolute inset-x-0 -top-8 -bottom-6 w-full bg-gradient-to-b from-[#07080C]/90 via-[#0A0D14]/65 to-transparent pointer-events-none -z-10"
              />

              {/* Small Editorial Label - Reduced refined font size */}
              <div className="inline-flex items-center gap-1.5 mb-1 px-4">
                <span className="w-3.5 h-[1px] bg-gradient-to-r from-transparent to-[#D8B263]/80" />
                <span className="text-[8px] xs:text-[8.5px] font-mono uppercase tracking-[0.25em] text-[#D8B263] font-medium drop-shadow-[0_2px_4px_rgba(0,0,0,0.8)]">
                  EDITION 01 &bull; CHRONOMÉTRIE
                </span>
                <span className="w-3.5 h-[1px] bg-gradient-to-l from-transparent to-[#D8B263]/80" />
              </div>

              {/* Main Headline: TIMELESS ELEGANCE - Refined smaller luxury serif font size */}
              <h1 className="w-full px-4 font-serif-luxury uppercase font-bold text-[22px] xs:text-[25px] sm:text-[28px] tracking-[0.05em] leading-[1.08] text-center drop-shadow-[0_4px_16px_rgba(0,0,0,0.95)]">
                <span className="text-[#F7F5F0]">TIMELESS </span>
                <span className="text-transparent bg-clip-text bg-gradient-to-r from-[#FFF0D0] via-[#D8B263] to-[#B08A38]">
                  ELEGANCE
                </span>
              </h1>

              {/* Subtitle - Reduced font size */}
              <h2 className="px-4 font-sans-modern text-[10px] xs:text-[10.5px] font-medium text-[#E8D9BF] tracking-[0.14em] uppercase mt-1 drop-shadow-[0_2px_6px_rgba(0,0,0,0.8)]">
                Discover the Art of Luxury
              </h2>

              {/* Supporting Text: Pure white, smaller font size, neat line height */}
              <p className="font-sans-modern text-[9.5px] xs:text-[10px] text-white/95 leading-relaxed font-normal w-full max-w-xs px-4 mt-1 drop-shadow-[0_2px_8px_rgba(0,0,0,0.95)]">
                Every second tells a story.
                <br />
                Crafted for those who value timeless elegance and extraordinary detail.
              </p>

              {/* Call to Action Button: Compact rounded pill shape with smaller font size */}
              <button
                type="button"
                onClick={() => {
                  const el = document.getElementById('collections');
                  if (el) el.scrollIntoView({ behavior: 'smooth' });
                }}
                className="mt-2 px-5 py-1.5 rounded-full border border-[#D8B263]/80 hover:border-[#D8B263] bg-black/60 hover:bg-[#D8B263] text-[#F5EAD4] hover:text-black font-sans-modern text-[9.5px] xs:text-[10px] font-semibold uppercase tracking-[0.18em] transition-all duration-300 flex items-center justify-center gap-1.5 cursor-pointer shadow-lg shadow-black/60 active:scale-95 shrink-0"
              >
                <span>EXPLORE COLLECTION</span>
                <span className="text-xs leading-none">&rarr;</span>
              </button>

              {/* Subtle Downward Scroll Indicator */}
              <div className="mt-1.5 flex flex-col items-center gap-1 opacity-70">
                <div className="w-[1px] h-2.5 bg-gradient-to-b from-[#D8B263]/80 to-transparent animate-pulse" />
              </div>
            </div>
          </div>

          {/* HEADING 2 - BOTTOM AREA OF MOBILE SCREEN */}
          <div
            style={mobileStage2Style}
            className="absolute inset-x-0 bottom-12 xs:bottom-16 z-20 px-6 flex flex-col items-center text-center select-none"
          >
            <div className="flex flex-col items-center max-w-sm mobile-hero-panel">
              <div className="inline-flex items-center gap-2 mb-2">
                <span className="w-4 h-[1px] bg-gradient-to-r from-transparent to-[#deb874]" />
                <span className="text-[9.5px] font-mono uppercase tracking-[0.26em] text-[#deb874] font-medium drop-shadow-[0_2px_4px_rgba(0,0,0,0.95)]">
                  02 &bull; Calibre 880
                </span>
                <span className="w-4 h-[1px] bg-gradient-to-l from-transparent to-[#deb874]" />
              </div>

              <h2 className="font-serif uppercase font-semibold text-2xl xs:text-3xl tracking-tight leading-tight text-white drop-shadow-[0_4px_16px_rgba(0,0,0,0.95)]">
                <span className="text-transparent bg-clip-text bg-gradient-to-r from-[#fae8c0] via-[#dfb66d] to-[#c99738]">
                  CRAFTED TO{' '}
                </span>
                <span className="text-white">PERFECTION.</span>
              </h2>

              <div className="text-xs xs:text-sm font-light text-[#f0deb8] tracking-wide mt-1.5 drop-shadow-[0_2px_10px_rgba(0,0,0,0.95)]">
                Precision Meets Passion
              </div>

              <p className="text-[11.5px] text-zinc-300 leading-relaxed font-normal max-w-xs mt-1.5 drop-shadow-[0_2px_10px_rgba(0,0,0,0.95)]">
                Designed with precision, built with passion. Exceptional craftsmanship in every component.
              </p>
            </div>
          </div>

          {/* HEADING 3 - SAME LOWER VISUAL AREA OF MOBILE SCREEN */}
          <div
            style={mobileStage3Style}
            className="absolute inset-x-0 bottom-12 xs:bottom-16 z-20 px-6 flex flex-col items-center text-center select-none"
          >
            <div className="flex flex-col items-center max-w-sm mobile-hero-panel">
              <div className="inline-flex items-center gap-2 mb-2">
                <span className="w-4 h-[1px] bg-gradient-to-r from-transparent to-[#deb874]" />
                <span className="text-[9.5px] font-mono uppercase tracking-[0.26em] text-[#deb874] font-medium drop-shadow-[0_2px_4px_rgba(0,0,0,0.95)]">
                  03 &bull; Geneva Seal
                </span>
                <span className="w-4 h-[1px] bg-gradient-to-l from-transparent to-[#deb874]" />
              </div>

              <h2 className="font-serif uppercase font-semibold text-2xl xs:text-3xl tracking-tight leading-tight text-white drop-shadow-[0_4px_16px_rgba(0,0,0,0.95)]">
                <span className="text-white">BEYOND </span>
                <span className="text-transparent bg-clip-text bg-gradient-to-r from-[#fae8c0] via-[#dfb66d] to-[#c99738]">
                  TIME.
                </span>
              </h2>

              <div className="text-xs xs:text-sm font-light text-[#f0deb8] tracking-wide mt-1.5 drop-shadow-[0_2px_10px_rgba(0,0,0,0.95)]">
                A Legacy on Your Wrist
              </div>

              <p className="text-[11.5px] text-zinc-300 leading-relaxed font-normal max-w-xs mt-1.5 drop-shadow-[0_2px_10px_rgba(0,0,0,0.95)]">
                More than a timepiece. A statement of individuality, precision, and enduring style.
              </p>
            </div>
          </div>

          {/* HEADING 4 - SAME LOWER VISUAL AREA OF MOBILE SCREEN */}
          <div
            style={mobileStage4Style}
            className="absolute inset-x-0 bottom-12 xs:bottom-16 z-20 px-6 flex flex-col items-center text-center select-none"
          >
            <div className="flex flex-col items-center max-w-sm mobile-hero-panel">
              <div className="inline-flex items-center gap-2 mb-2">
                <span className="w-4 h-[1px] bg-gradient-to-r from-transparent to-[#deb874]" />
                <span className="text-[9.5px] font-mono uppercase tracking-[0.26em] text-[#deb874] font-medium drop-shadow-[0_2px_4px_rgba(0,0,0,0.95)]">
                  04 &bull; Perpetual
                </span>
                <span className="w-4 h-[1px] bg-gradient-to-l from-transparent to-[#deb874]" />
              </div>

              <h2 className="font-serif uppercase font-semibold text-2xl xs:text-3xl tracking-tight leading-tight text-white drop-shadow-[0_4px_16px_rgba(0,0,0,0.95)]">
                <span className="text-transparent bg-clip-text bg-gradient-to-r from-[#fae8c0] via-[#dfb66d] to-[#c99738]">
                  DEFINE{' '}
                </span>
                <span className="text-white">YOUR LEGACY.</span>
              </h2>

              <div className="text-xs xs:text-sm font-light text-[#f0deb8] tracking-wide mt-1.5 drop-shadow-[0_2px_10px_rgba(0,0,0,0.95)]">
                Make Every Moment Count
              </div>

              <p className="text-[11.5px] text-zinc-300 leading-relaxed font-normal max-w-xs mt-1.5 drop-shadow-[0_2px_10px_rgba(0,0,0,0.95)]">
                Own every moment with a timepiece that represents your ambition, identity, and extraordinary journey.
              </p>
            </div>
          </div>

        </div>

        {/* ==================== 2. DESKTOP HERO TYPOGRAPHY BLOCKS (FINAL & UNTOUCHED) ==================== */}
        <div className="hidden md:flex absolute inset-0 z-20 pointer-events-none items-center justify-center overflow-hidden">
          <div className="w-full max-w-7xl mx-auto px-6 sm:px-10 lg:px-16 relative h-[70vh] flex items-center">

            {/* BLOCK 1 – LEFT */}
            <div
              style={stage1Style}
              className="absolute left-0 top-1/2 -translate-y-1/2 max-w-sm lg:max-w-md text-left flex flex-col items-start select-none"
            >
              <div className="self-start inline-flex items-center gap-2.5 mb-2.5 text-left">
                <span className="w-7 h-[1px] bg-gradient-to-r from-amber-400 to-amber-200/30" />
                <span className="text-xs font-mono uppercase tracking-[0.25em] text-[#deb874]">
                  Edition 01 &bull; Chronométrie
                </span>
              </div>
              <h1
                style={{ fontSize: 'clamp(2rem, 3.4vw, 3.25rem)' }}
                className="text-left w-full font-serif uppercase font-semibold tracking-tight leading-[1.08] drop-shadow-lg"
              >
                <span className="text-white">TIMELESS </span>
                <span className="text-transparent bg-clip-text bg-gradient-to-r from-[#fae8c0] via-[#dfb66d] to-[#c99738]">
                  ELEGANCE.
                </span>
              </h1>
              <h2 className="text-left w-full text-base lg:text-lg font-light text-[#f0deb8] tracking-wide mt-2 mb-2">
                Discover the Art of Luxury
              </h2>
              <p className="text-left self-start text-sm lg:text-[15px] text-white/90 leading-relaxed font-normal max-w-xs lg:max-w-sm drop-shadow-[0_2px_6px_rgba(0,0,0,0.9)]">
                Every second tells a story. Experience watches crafted for those who value timeless elegance and extraordinary detail.
              </p>
            </div>

            {/* BLOCK 2 – RIGHT */}
            <div
              style={stage2Style}
              className="absolute -right-6 sm:-right-8 lg:-right-12 xl:-right-16 top-1/2 -translate-y-1/2 max-w-sm lg:max-w-md ml-auto text-left flex flex-col items-start select-none"
            >
              <div className="self-start inline-flex items-center gap-2.5 mb-2.5 text-left">
                <span className="w-7 h-[1px] bg-gradient-to-r from-amber-400 to-amber-200/30" />
                <span className="text-xs font-mono uppercase tracking-[0.25em] text-[#deb874]">
                  Haute Horlogerie &bull; Calibre 880
                </span>
              </div>
              <h1
                style={{ fontSize: 'clamp(1.65rem, 2.6vw, 2.4rem)' }}
                className="text-left w-full font-serif uppercase font-semibold tracking-tight leading-[1.1] drop-shadow-lg"
              >
                <span className="text-transparent bg-clip-text bg-gradient-to-r from-[#fae8c0] via-[#dfb66d] to-[#c99738]">
                  CRAFTED TO{' '}
                </span>
                <span className="text-white">PERFECTION.</span>
              </h1>
              <h2 className="text-left w-full text-base lg:text-lg font-light text-[#f0deb8] tracking-wide mt-2 mb-2">
                Precision Meets Passion
              </h2>
              <p className="text-left self-start text-sm lg:text-[15px] text-white/90 leading-relaxed font-normal max-w-xs lg:max-w-sm drop-shadow-[0_2px_6px_rgba(0,0,0,0.9)]">
                Designed with precision, built with passion. Every detail reflects exceptional craftsmanship and uncompromising quality.
              </p>
            </div>

            {/* BLOCK 3 – LEFT */}
            <div
              style={stage3Style}
              className="absolute left-0 top-1/2 -translate-y-1/2 max-w-sm lg:max-w-md text-left flex flex-col items-start select-none"
            >
              <div className="self-start inline-flex items-center gap-2.5 mb-2.5 text-left">
                <span className="w-7 h-[1px] bg-gradient-to-r from-amber-400 to-amber-200/30" />
                <span className="text-xs font-mono uppercase tracking-[0.25em] text-[#deb874]">
                  Master Heritage &bull; Geneva Seal
                </span>
              </div>
              <h1
                style={{ fontSize: 'clamp(1.65rem, 2.6vw, 2.4rem)' }}
                className="text-left w-full font-serif uppercase font-semibold tracking-tight leading-[1.1] drop-shadow-lg"
              >
                <span className="text-white">BEYOND </span>
                <span className="text-transparent bg-clip-text bg-gradient-to-r from-[#fae8c0] via-[#dfb66d] to-[#c99738]">
                  TIME.
                </span>
              </h1>
              <h2 className="text-left w-full text-base lg:text-lg font-light text-[#f0deb8] tracking-wide mt-2 mb-2">
                A Legacy on Your Wrist
              </h2>
              <p className="text-left self-start text-sm lg:text-[15px] text-white/90 leading-relaxed font-normal max-w-xs lg:max-w-sm drop-shadow-[0_2px_6px_rgba(0,0,0,0.9)]">
                More than a timepiece. A statement of individuality, confidence, and a style that never goes out of fashion.
              </p>
            </div>

            {/* BLOCK 4 – RIGHT */}
            <div
              style={stage4Style}
              className="absolute right-0 top-1/2 -translate-y-1/2 max-w-sm lg:max-w-md ml-auto text-left flex flex-col items-start select-none"
            >
              <div className="self-start inline-flex items-center gap-2.5 mb-2.5 text-left">
                <span className="w-7 h-[1px] bg-gradient-to-r from-amber-400 to-amber-200/30" />
                <span className="text-xs font-mono uppercase tracking-[0.25em] text-[#deb874]">
                  Grand Complication &bull; Perpetual
                </span>
              </div>
              <h1
                style={{ fontSize: 'clamp(1.65rem, 2.6vw, 2.4rem)' }}
                className="text-left w-full font-serif uppercase font-semibold tracking-tight leading-[1.1] drop-shadow-lg"
              >
                <span className="text-transparent bg-clip-text bg-gradient-to-r from-[#fae8c0] via-[#dfb66d] to-[#c99738]">
                  DEFINE{' '}
                </span>
                <span className="text-white">YOUR LEGACY.</span>
              </h1>
              <h2 className="text-left w-full text-base lg:text-lg font-light text-[#f0deb8] tracking-wide mt-2 mb-2">
                Make Every Moment Count
              </h2>
              <p className="text-left self-start text-sm lg:text-[15px] text-white/90 leading-relaxed font-normal max-w-xs lg:max-w-sm drop-shadow-[0_2px_6px_rgba(0,0,0,0.9)]">
                Own every moment with a timepiece that represents your ambition, your identity, and your extraordinary journey.
              </p>
            </div>

          </div>
        </div>

        {/* Scroll Indicator at Initial Stage - Desktop Only */}
        <div
          style={{
            opacity: Math.max(0, 1 - smoothProgress * 10),
            transition: 'opacity 0.2s ease',
          }}
          className="hidden md:flex absolute bottom-8 left-1/2 -translate-x-1/2 z-20 pointer-events-none flex-col items-center gap-2 select-none"
        >
          <span className="text-[10px] tracking-[0.3em] uppercase text-zinc-400 font-mono">
            Scroll to Explore
          </span>
          <div className="w-[1px] h-6 bg-gradient-to-b from-amber-400/60 to-transparent animate-pulse" />
        </div>

      </div>
    </section>
  );
};
