import React, { useState } from 'react';
import { Search, X, ArrowRight } from 'lucide-react';
import { PRODUCTS, Product } from '../data/products';

interface SearchModalProps {
  isOpen: boolean;
  onClose: () => void;
  onSelectProduct: (product: Product) => void;
}

export const SearchModal: React.FC<SearchModalProps> = ({
  isOpen,
  onClose,
  onSelectProduct,
}) => {
  const [query, setQuery] = useState('');

  if (!isOpen) return null;

  const results = query.trim() === ''
    ? PRODUCTS.slice(0, 4)
    : PRODUCTS.filter((p) => {
        const q = query.toLowerCase();
        return (
          p.name.toLowerCase().includes(q) ||
          p.reference.toLowerCase().includes(q) ||
          (p.collection ? p.collection.toLowerCase().includes(q) : false) ||
          p.style.toLowerCase().includes(q) ||
          p.calibre.toLowerCase().includes(q)
        );
      });

  return (
    <div className="fixed inset-0 z-50 overflow-y-auto bg-black/80 backdrop-blur-md flex items-start justify-center pt-20 px-4 sm:px-6 animate-in fade-in duration-200">
      <div 
        className="relative w-full max-w-2xl bg-[#0E0E12] border border-white/10 rounded-sm shadow-2xl overflow-hidden"
        onClick={(e) => e.stopPropagation()}
      >
        {/* Search Input Bar */}
        <div className="p-4 sm:p-6 border-b border-white/10 flex items-center gap-3">
          <Search className="w-5 h-5 text-[#C9A050] shrink-0" />
          <input
            type="text"
            autoFocus
            value={query}
            onChange={(e) => setQuery(e.target.value)}
            placeholder="Search by model, reference, titanium, tourbillon, ceramic..."
            className="w-full bg-transparent text-sm sm:text-base text-white placeholder-zinc-500 focus:outline-none font-sans-modern"
          />
          <button
            onClick={onClose}
            className="p-1.5 text-zinc-400 hover:text-white rounded-full hover:bg-white/5 transition-colors cursor-pointer"
          >
            <X className="w-5 h-5" />
          </button>
        </div>

        {/* Results List */}
        <div className="p-4 sm:p-6 max-h-[60vh] overflow-y-auto space-y-3">
          <div className="text-[10px] uppercase tracking-widest font-mono text-zinc-500 mb-2">
            {query.trim() === '' ? 'Curated Masterpieces' : `Found ${results.length} References`}
          </div>

          {results.length === 0 ? (
            <div className="py-8 text-center text-zinc-500 text-xs">
              No references matched your inquiry.
            </div>
          ) : (
            results.map((product) => (
              <div
                key={product.id}
                onClick={() => {
                  onSelectProduct(product);
                  onClose();
                }}
                className="group p-3 rounded-sm bg-white/5 hover:bg-[#16161D] border border-transparent hover:border-[#C9A050]/40 transition-all flex items-center justify-between cursor-pointer"
              >
                <div className="flex items-center gap-4">
                  <div className="w-12 h-12 bg-black/40 rounded-sm p-1 shrink-0 flex items-center justify-center">
                    <img
                      src={product.image}
                      alt={product.name}
                      referrerPolicy="no-referrer"
                      className="w-full h-full object-contain"
                    />
                  </div>
                  <div>
                    <div className="text-[10px] font-mono text-[#C9A050]">{product.reference}</div>
                    <h4 className="text-xs font-semibold text-white group-hover:text-[#D8B263] transition-colors font-serif-luxury">
                      {product.name}
                    </h4>
                    <div className="text-[11px] text-zinc-400 font-sans-modern">
                      {product.material} · {product.caseSize}
                    </div>
                  </div>
                </div>

                <div className="text-right">
                  <div className="text-xs font-serif-luxury font-bold text-white tabular-nums">
                    ${product.price.toLocaleString()}
                  </div>
                  <div className="text-[10px] text-[#C9A050] flex items-center gap-1 opacity-0 group-hover:opacity-100 transition-opacity">
                    <span>View Specs</span>
                    <ArrowRight className="w-3 h-3" />
                  </div>
                </div>
              </div>
            ))
          )}
        </div>

      </div>
    </div>
  );
};
