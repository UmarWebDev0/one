import React, { useState } from 'react';
import { Product } from '../data/products';
import { X, ShieldCheck, Truck, RotateCcw, Check, Clock, Layers, Compass, Sparkles } from 'lucide-react';

interface ProductDetailModalProps {
  product: Product | null;
  onClose: () => void;
  onAddToCart: (product: Product, options?: { strapColor?: string; customEngraving?: string }) => void;
  onBookAppointment: () => void;
}

export const ProductDetailModal: React.FC<ProductDetailModalProps> = ({
  product,
  onClose,
  onAddToCart,
  onBookAppointment,
}) => {
  const [selectedStrap, setSelectedStrap] = useState<string>('Standard Lined Rubber');
  const [engravingText, setEngravingText] = useState<string>('');
  const [showEngravingInput, setShowEngravingInput] = useState<boolean>(false);
  const [isAdded, setIsAdded] = useState<boolean>(false);

  if (!product) return null;

  const strapOptions = [
    'Standard Lined Rubber',
    'Matte Alligator Leather',
    'Tactical Cordura Fabric',
  ];

  const handleAdd = () => {
    onAddToCart(product, {
      strapColor: selectedStrap,
      customEngraving: showEngravingInput ? engravingText : undefined,
    });
    setIsAdded(true);
    setTimeout(() => setIsAdded(false), 2000);
  };

  return (
    <div className="fixed inset-0 z-50 overflow-y-auto bg-black/25 flex items-center justify-center p-4 sm:p-6 lg:p-8 animate-in fade-in duration-200">
      <div 
        className="relative w-full max-w-5xl bg-[#0B0B0E]/95 backdrop-blur-xl border border-white/10 rounded-sm shadow-2xl overflow-hidden my-auto"
        onClick={(e) => e.stopPropagation()}
      >
        {/* Close Button */}
        <button
          onClick={onClose}
          className="absolute top-4 right-4 z-30 p-2.5 rounded-full bg-black/60 text-zinc-400 hover:text-white hover:bg-black/80 transition-all border border-white/10 cursor-pointer"
          aria-label="Close modal"
        >
          <X className="w-5 h-5" />
        </button>

        {/* 2-Column Split: Visual Gallery Left, Contiguous Purchase Module Right */}
        <div className="grid grid-cols-1 lg:grid-cols-12 min-h-[580px]">
          
          {/* Left Column: Visual Showcase */}
          <div className="lg:col-span-6 bg-[#0E0E12] p-8 sm:p-12 flex flex-col justify-between relative border-b lg:border-b-0 lg:border-r border-white/10">
            {/* Subtle glow */}
            <div className="absolute inset-0 bg-radial from-[#C9A050]/5 to-transparent pointer-events-none" />

            <div className="flex items-center justify-between text-xs font-mono text-zinc-500">
              <span>{product.reference}</span>
              <span className="text-[#C9A050] uppercase tracking-wider">{product.category}</span>
            </div>

            {/* Main Image */}
            <div className="relative my-auto py-6 flex items-center justify-center aspect-square max-h-[420px]">
              <img
                src={product.image}
                alt={product.name}
                referrerPolicy="no-referrer"
                className="w-full h-full object-contain filter drop-shadow-[0_20px_30px_rgba(0,0,0,0.8)]"
              />
            </div>

            {/* Micro Technical Strip */}
            <div className="grid grid-cols-3 gap-2 pt-4 border-t border-white/10 text-center text-xs font-sans-modern">
              <div>
                <span className="text-zinc-500 text-[10px] uppercase tracking-wider block">Calibre</span>
                <span className="text-white font-medium text-[11px] truncate block">{product.calibre.split(' ')[1] || 'V-800'}</span>
              </div>
              <div>
                <span className="text-zinc-500 text-[10px] uppercase tracking-wider block">Reserve</span>
                <span className="text-white font-medium text-[11px] block">{product.powerReserve}</span>
              </div>
              <div>
                <span className="text-zinc-500 text-[10px] uppercase tracking-wider block">Water Resist</span>
                <span className="text-white font-medium text-[11px] block">{product.waterResistance}</span>
              </div>
            </div>
          </div>

          {/* Right Column: Contiguous Purchase Module */}
          <div className="lg:col-span-6 p-8 sm:p-10 flex flex-col justify-between bg-[#0B0B0E]">
            <div>
              {/* Collection & Availability */}
              <div className="flex items-center justify-between gap-4 mb-2">
                <span className="text-xs uppercase tracking-widest text-[#C9A050] font-sans-modern font-semibold">
                  {product.collection || product.style} Collection
                </span>
                <span className={`text-[11px] font-sans-modern tracking-wider uppercase font-medium ${product.inStock ? 'text-emerald-400' : 'text-amber-400'}`}>
                  {product.inStock ? 'Available for Allocation' : 'Waitlist Only'}
                </span>
              </div>

              {/* Title & Price */}
              <h2 className="font-serif-luxury text-2xl sm:text-3xl font-bold text-white mb-2 leading-tight">
                {product.name}
              </h2>
              <div className="text-2xl font-serif-luxury font-bold text-white mb-6 tabular-nums">
                ${product.price.toLocaleString()} <span className="text-xs font-sans-modern text-zinc-400 font-normal">USD</span>
              </div>

              {/* Description */}
              <p className="text-xs sm:text-sm text-zinc-300 font-sans-modern leading-relaxed mb-6">
                {product.description}
              </p>

              {/* Technical Specifications List */}
              <div className="space-y-2 mb-6 p-4 bg-white/5 rounded-sm border border-white/5 text-xs text-zinc-300 font-sans-modern">
                <div className="flex justify-between py-1 border-b border-white/5">
                  <span className="text-zinc-400">Case Material:</span>
                  <span className="text-white font-medium">{product.material}</span>
                </div>
                <div className="flex justify-between py-1 border-b border-white/5">
                  <span className="text-zinc-400">Diameter:</span>
                  <span className="text-white font-medium">{product.caseSize}</span>
                </div>
                <div className="flex justify-between py-1 border-b border-white/5">
                  <span className="text-zinc-400">Movement:</span>
                  <span className="text-white font-medium">{product.calibre}</span>
                </div>
                <div className="flex justify-between py-1">
                  <span className="text-zinc-400">Included Strap:</span>
                  <span className="text-white font-medium truncate max-w-[200px]">{product.strap}</span>
                </div>
              </div>

              {/* Strap Variant Selector */}
              <div className="mb-6">
                <label className="block text-xs uppercase tracking-wider text-zinc-400 font-sans-modern mb-2">
                  Select Interchangeable Strap Option
                </label>
                <div className="grid grid-cols-3 gap-2">
                  {strapOptions.map((strap) => (
                    <button
                      key={strap}
                      onClick={() => setSelectedStrap(strap)}
                      className={`p-2 text-center text-[11px] font-sans-modern rounded-sm transition-all cursor-pointer ${
                        selectedStrap === strap
                          ? 'bg-[#C9A050]/20 text-[#D8B263] border border-[#C9A050]/50 font-medium'
                          : 'bg-white/5 text-zinc-400 border border-white/5 hover:bg-white/10 hover:text-white'
                      }`}
                    >
                      {strap}
                    </button>
                  ))}
                </div>
              </div>

              {/* Optional Caseback Engraving Toggle */}
              <div className="mb-6">
                <button
                  type="button"
                  onClick={() => setShowEngravingInput(!showEngravingInput)}
                  className="text-xs text-[#D8B263] hover:underline flex items-center gap-1.5 cursor-pointer font-sans-modern"
                >
                  <span>{showEngravingInput ? '− Remove Bespoke Engraving' : '+ Add Complimentary Sapphire/Titanium Engraving'}</span>
                </button>
                {showEngravingInput && (
                  <div className="mt-2 animate-in fade-in duration-200">
                    <input
                      type="text"
                      maxLength={24}
                      value={engravingText}
                      onChange={(e) => setEngravingText(e.target.value)}
                      placeholder="e.g. A.V. · GENÈVE · MMXXVI (max 24 chars)"
                      className="w-full bg-[#141418] border border-white/10 rounded-sm px-3 py-2 text-xs font-mono text-white placeholder-zinc-500 focus:outline-none focus:border-[#C9A050]"
                    />
                    <div className="text-[10px] text-zinc-500 mt-1">Laser engraved on caseback rim by master artisans</div>
                  </div>
                )}
              </div>
            </div>

            {/* Bottom Actions & Trust Markers */}
            <div className="pt-6 border-t border-white/10 space-y-4">
              <div className="flex flex-col sm:flex-row gap-3">
                <button
                  onClick={handleAdd}
                  disabled={!product.inStock}
                  className={`flex-1 py-3.5 px-6 font-sans-modern text-xs font-semibold tracking-wider uppercase rounded-sm transition-all flex items-center justify-center gap-2 cursor-pointer ${
                    !product.inStock
                      ? 'bg-zinc-800 text-zinc-500 cursor-not-allowed'
                      : isAdded
                      ? 'bg-emerald-600 text-white'
                      : 'bg-gradient-to-r from-[#D8B263] to-[#B08A38] text-black hover:brightness-110 shadow-lg shadow-[#D8B263]/20'
                  }`}
                >
                  {isAdded ? (
                    <>
                      <Check className="w-4 h-4" />
                      <span>Added to Shopping Bag</span>
                    </>
                  ) : product.inStock ? (
                    <span>Acquire Timepiece</span>
                  ) : (
                    <span>Join Allocation Waitlist</span>
                  )}
                </button>

                <button
                  onClick={() => {
                    onClose();
                    onBookAppointment();
                  }}
                  className="py-3.5 px-5 border border-white/20 text-white hover:border-[#C9A050] hover:text-[#D8B263] font-sans-modern text-xs font-semibold tracking-wider uppercase rounded-sm transition-all text-center cursor-pointer"
                >
                  Atelier Viewing
                </button>
              </div>

              {/* Trust Indicators */}
              <div className="grid grid-cols-3 gap-2 pt-2 text-[10px] text-zinc-400 font-sans-modern">
                <div className="flex items-center gap-1.5">
                  <ShieldCheck className="w-3.5 h-3.5 text-[#C9A050] shrink-0" />
                  <span>5-Year Manufacture Warranty</span>
                </div>
                <div className="flex items-center gap-1.5">
                  <Truck className="w-3.5 h-3.5 text-[#C9A050] shrink-0" />
                  <span>Armored Armored Delivery</span>
                </div>
                <div className="flex items-center gap-1.5">
                  <RotateCcw className="w-3.5 h-3.5 text-[#C9A050] shrink-0" />
                  <span>30-Day Atelier Return</span>
                </div>
              </div>
            </div>

          </div>

        </div>
      </div>
    </div>
  );
};
