import React, { useState } from 'react';
import { ShieldCheck, MessageSquare, PhoneCall, Award, Send, CheckCircle2 } from 'lucide-react';
import { motion } from 'motion/react';

export const Concierge: React.FC = () => {
  const [formSubmitted, setFormSubmitted] = useState(false);
  const [formData, setFormData] = useState({
    fullName: '',
    email: '',
    phone: '',
    inquiryType: 'Private Allocation',
    preferredTimepiece: 'Monolith Skeleton Tourbillon',
    message: '',
  });

  const handleSubmit = (e: React.FormEvent) => {
    e.preventDefault();
    setFormSubmitted(true);
  };

  return (
    <section id="concierge" className="pt-12 sm:pt-20 pb-16 sm:pb-32 bg-[#070708] border-t border-white/5 relative">
      <div className="max-w-7xl mx-auto px-5 sm:px-8 lg:px-12">
        
        <div className="grid grid-cols-1 lg:grid-cols-12 gap-8 sm:gap-12 items-center">
          
          {/* Left Info Column with Scroll-Replay Animation */}
          <motion.div 
            initial={{ opacity: 0, x: -22 }}
            whileInView={{ opacity: 1, x: 0 }}
            viewport={{ once: false, amount: 0.2 }}
            transition={{ duration: 0.55, ease: [0.16, 1, 0.3, 1] }}
            className="lg:col-span-5 space-y-5 sm:space-y-8"
          >
            <div>
              <div className="flex items-center gap-2 text-[10px] sm:text-xs tracking-[0.25em] text-[#C9A050] uppercase font-sans-modern font-semibold mb-2 sm:mb-3">
                <span>Private Client Relations</span>
                <span className="w-8 h-[1px] bg-[#C9A050]/50" />
              </div>
              <h2 className="font-serif-luxury text-2xl sm:text-4xl lg:text-5xl font-bold text-white tracking-tight mb-3 sm:mb-4 text-balance">
                ATELIER CONCIERGE & PRIVATE ALLOCATIONS
              </h2>
              <p className="text-zinc-400 font-sans-modern text-xs sm:text-sm leading-relaxed">
                Our Private Client Concierge provides confidential consultation, bespoke movement configuration, and discreet armored delivery worldwide.
              </p>
            </div>

            <div className="space-y-3 sm:space-y-4 pt-3 sm:pt-4 border-t border-white/10">
              <div className="flex items-start gap-3 sm:gap-4">
                <div className="p-2 sm:p-2.5 rounded-sm bg-white/5 text-[#C9A050] border border-white/5 shrink-0">
                  <ShieldCheck className="w-4 h-4 sm:w-5 sm:h-5" />
                </div>
                <div>
                  <h4 className="text-xs sm:text-sm font-semibold text-white font-sans-modern">Discreet Armored Logistics</h4>
                  <p className="text-[11px] sm:text-xs text-zinc-400 font-sans-modern mt-0.5">
                    Fully insured global white-glove transport with real-time biometric verification upon handoff.
                  </p>
                </div>
              </div>

              <div className="flex items-start gap-3 sm:gap-4">
                <div className="p-2 sm:p-2.5 rounded-sm bg-white/5 text-[#C9A050] border border-white/5 shrink-0">
                  <Award className="w-4 h-4 sm:w-5 sm:h-5" />
                </div>
                <div>
                  <h4 className="text-xs sm:text-sm font-semibold text-white font-sans-modern">Lifetime Movement Care</h4>
                  <p className="text-[11px] sm:text-xs text-zinc-400 font-sans-modern mt-0.5">
                    Every Vauban calibre includes perpetual chronometric recalibration and ultrasonic cleaning in Geneva.
                  </p>
                </div>
              </div>

              <div className="flex items-start gap-3 sm:gap-4">
                <div className="p-2 sm:p-2.5 rounded-sm bg-white/5 text-[#C9A050] border border-white/5 shrink-0">
                  <PhoneCall className="w-4 h-4 sm:w-5 sm:h-5" />
                </div>
                <div>
                  <h4 className="text-xs sm:text-sm font-semibold text-white font-sans-modern">24/7 Dedicated Watchmaker Access</h4>
                  <p className="text-[11px] sm:text-xs text-zinc-400 font-sans-modern mt-0.5">
                    Direct communication with our master watchmakers for technical advisory and bespoke requests.
                  </p>
                </div>
              </div>
            </div>
          </motion.div>

          {/* Right Form Column with Scroll-Replay Animation - Compact on Mobile */}
          <motion.div 
            initial={{ opacity: 0, x: 22 }}
            whileInView={{ opacity: 1, x: 0 }}
            viewport={{ once: false, amount: 0.2 }}
            transition={{ duration: 0.55, delay: 0.1, ease: [0.16, 1, 0.3, 1] }}
            className="lg:col-span-7 bg-[#0E0E12] border border-white/10 rounded-sm p-4 sm:p-10 relative"
          >
            {formSubmitted ? (
              <div className="py-6 sm:py-12 text-center space-y-3 sm:space-y-4 animate-in fade-in duration-300">
                <div className="w-12 h-12 sm:w-14 sm:h-14 mx-auto rounded-full bg-[#C9A050]/20 border border-[#C9A050]/50 flex items-center justify-center text-[#D8B263]">
                  <CheckCircle2 className="w-6 h-6 sm:w-8 sm:h-8" />
                </div>
                <h3 className="font-serif-luxury text-xl sm:text-2xl font-bold text-white">
                  INQUIRY TRANSMITTED CONFIDENTIALLY
                </h3>
                <p className="text-xs sm:text-sm text-zinc-400 font-sans-modern max-w-md mx-auto leading-relaxed">
                  Thank you, <span className="text-white font-medium">{formData.fullName}</span>. A senior horological advisor from our Geneva atelier will contact you within 2 hours.
                </p>
                <div className="pt-2 sm:pt-4">
                  <button
                    onClick={() => {
                      setFormSubmitted(false);
                      setFormData({
                        fullName: '',
                        email: '',
                        phone: '',
                        inquiryType: 'Private Allocation',
                        preferredTimepiece: 'Monolith Skeleton Tourbillon',
                        message: '',
                      });
                    }}
                    className="px-5 sm:px-6 py-2 sm:py-2.5 border border-white/20 text-xs font-sans-modern uppercase tracking-wider text-white hover:border-[#C9A050] rounded-sm cursor-pointer"
                  >
                    Submit Another Inquiry
                  </button>
                </div>
              </div>
            ) : (
              <form onSubmit={handleSubmit} className="space-y-3 sm:space-y-4 font-sans-modern">
                <div className="border-b border-white/10 pb-3 sm:pb-4 mb-3 sm:mb-6">
                  <h3 className="font-serif-luxury text-lg sm:text-xl font-bold text-white">
                    REQUEST PRIVATE CONSULTATION
                  </h3>
                  <p className="text-[11px] sm:text-xs text-zinc-400 mt-0.5 sm:mt-1">
                    Please provide your contact details to receive our confidential collector portfolio.
                  </p>
                </div>

                <div className="grid grid-cols-1 sm:grid-cols-2 gap-3 sm:gap-4">
                  <div>
                    <label className="block text-[10px] sm:text-xs uppercase tracking-wider text-zinc-400 mb-1 sm:mb-1.5">
                      Full Name *
                    </label>
                    <input
                      type="text"
                      required
                      value={formData.fullName}
                      onChange={(e) => setFormData({ ...formData, fullName: e.target.value })}
                      placeholder="e.g. Lord Sterling Alexander"
                      className="w-full bg-[#141418] border border-white/10 rounded-sm px-3 py-2 sm:px-3.5 sm:py-2.5 text-xs text-white placeholder-zinc-600 focus:outline-none focus:border-[#C9A050]"
                    />
                  </div>

                  <div>
                    <label className="block text-[10px] sm:text-xs uppercase tracking-wider text-zinc-400 mb-1.5">
                      Email Address *
                    </label>
                    <input
                      type="email"
                      required
                      value={formData.email}
                      onChange={(e) => setFormData({ ...formData, email: e.target.value })}
                      placeholder="e.g. sterling@alexander.ch"
                      className="w-full bg-[#141418] border border-white/10 rounded-sm px-3 py-2 sm:px-3.5 sm:py-2.5 text-xs text-white placeholder-zinc-600 focus:outline-none focus:border-[#C9A050]"
                    />
                  </div>
                </div>

                <div className="grid grid-cols-1 sm:grid-cols-2 gap-3 sm:gap-4">
                  <div>
                    <label className="block text-[10px] sm:text-xs uppercase tracking-wider text-zinc-400 mb-1 sm:mb-1.5">
                      Telephone / WhatsApp *
                    </label>
                    <input
                      type="tel"
                      required
                      value={formData.phone}
                      onChange={(e) => setFormData({ ...formData, phone: e.target.value })}
                      placeholder="e.g. +92 3412683864"
                      className="w-full bg-[#141418] border border-white/10 rounded-sm px-3 py-2 sm:px-3.5 sm:py-2.5 text-xs text-white placeholder-zinc-600 focus:outline-none focus:border-[#C9A050]"
                    />
                  </div>

                  <div>
                    <label className="block text-[10px] sm:text-xs uppercase tracking-wider text-zinc-400 mb-1 sm:mb-1.5">
                      Inquiry Focus
                    </label>
                    <select
                      value={formData.inquiryType}
                      onChange={(e) => setFormData({ ...formData, inquiryType: e.target.value })}
                      className="w-full bg-[#141418] border border-white/10 rounded-sm px-3 py-2 sm:px-3.5 sm:py-2.5 text-xs text-white focus:outline-none focus:border-[#C9A050]"
                    >
                      <option value="Private Allocation">Private Allocation Request</option>
                      <option value="Bespoke Commission">Bespoke Unique Piece Commission</option>
                      <option value="Atelier Salon Viewing">Atelier Salon Private Viewing</option>
                      <option value="Collection Authentication">Provenance & Authentication</option>
                    </select>
                  </div>
                </div>

                <div>
                  <label className="block text-[10px] sm:text-xs uppercase tracking-wider text-zinc-400 mb-1 sm:mb-1.5">
                    Timepiece of Interest
                  </label>
                  <select
                    value={formData.preferredTimepiece}
                    onChange={(e) => setFormData({ ...formData, preferredTimepiece: e.target.value })}
                    className="w-full bg-[#141418] border border-white/10 rounded-sm px-3 py-2 sm:px-3.5 sm:py-2.5 text-xs text-white focus:outline-none focus:border-[#C9A050]"
                  >
                    <option value="Monolith Skeleton Tourbillon">Monolith Skeleton Tourbillon ($42,500)</option>
                    <option value="Obsidian Chronograph All-Black">Obsidian Chronograph All-Black ($26,800)</option>
                    <option value="Aurelia Royal Gold Chronograph">Aurelia Royal Gold Chronograph ($51,200)</option>
                    <option value="Vapour Carbon Aerofusion">Vapour Carbon Aerofusion ($31,400)</option>
                    <option value="Spectra Sapphire Pure Crystal">Spectra Sapphire Pure Crystal ($88,000)</option>
                    <option value="Monolith Dual-Time GMT Titanium">Monolith Dual-Time GMT Titanium ($24,500)</option>
                  </select>
                </div>

                <div>
                  <label className="block text-[10px] sm:text-xs uppercase tracking-wider text-zinc-400 mb-1 sm:mb-1.5">
                    Personal Notes or Specific Requirements
                  </label>
                  <textarea
                    rows={2}
                    value={formData.message}
                    onChange={(e) => setFormData({ ...formData, message: e.target.value })}
                    placeholder="Provide any specific requirements, timing preferences, or delivery location..."
                    className="w-full bg-[#141418] border border-white/10 rounded-sm px-3 py-2 sm:px-3.5 sm:py-2.5 text-xs text-white placeholder-zinc-600 focus:outline-none focus:border-[#C9A050] resize-none"
                  />
                </div>

                <div className="pt-1.5 sm:pt-2">
                  <button
                    type="submit"
                    className="w-full py-2.5 sm:py-3.5 bg-gradient-to-r from-[#D8B263] to-[#B08A38] text-black text-xs font-semibold tracking-wider uppercase rounded-sm hover:brightness-110 transition-all flex items-center justify-center gap-2 cursor-pointer shadow-lg shadow-[#D8B263]/15"
                  >
                    <Send className="w-3.5 h-3.5" />
                    <span>Transmit Confidential Request</span>
                  </button>
                  <div className="text-[9px] sm:text-[10px] text-zinc-500 text-center mt-1.5 sm:mt-2">
                    Protected by Swiss banking-grade encryption standards. No marketing solicitations.
                  </div>
                </div>
              </form>
            )}
          </motion.div>

        </div>

      </div>
    </section>
  );
};
