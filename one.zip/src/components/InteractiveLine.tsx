import React, { useState, useRef } from 'react';
import { motion, AnimatePresence } from 'motion/react';
import { Sparkles, ArrowUpRight } from 'lucide-react';

export interface InteractiveLineWatchInfo {
  tag?: string;
  name: string;
  reference: string;
  calibre?: string;
  specs: string;
  image?: string;
}

interface InteractiveLineProps {
  watchInfo: InteractiveLineWatchInfo;
  className?: string;
  placement?: 'above' | 'below';
}

export const InteractiveLine: React.FC<InteractiveLineProps> = ({
  watchInfo,
  className = '',
  placement = 'above',
}) => {
  const lineRef = useRef<HTMLDivElement>(null);
  const [isHovered, setIsHovered] = useState(false);
  const [cursorPercent, setCursorPercent] = useState(50);

  const handleMouseMove = (e: React.MouseEvent<HTMLDivElement>) => {
    if (!lineRef.current) return;
    const rect = lineRef.current.getBoundingClientRect();
    const x = e.clientX - rect.left;
    const percent = Math.max(0, Math.min(100, (x / rect.width) * 100));
    setCursorPercent(percent);
  };

  // Clamp popup horizontal position so it never overflows off-screen
  const clampedPopupPercent = Math.max(16, Math.min(84, cursorPercent));

  return (
    <motion.div
      ref={lineRef}
      initial={{ opacity: 0, scaleX: 0.95 }}
      whileInView={{ opacity: 1, scaleX: 1 }}
      viewport={{ once: false, amount: 0.3 }}
      transition={{ duration: 0.7, ease: [0.16, 1, 0.3, 1] }}
      onMouseEnter={() => setIsHovered(true)}
      onMouseMove={handleMouseMove}
      onMouseLeave={() => setIsHovered(false)}
      className={`relative w-full py-5 cursor-pointer select-none group ${className}`}
      aria-label="Interactive horological timeline"
    >
      {/* Background Track Line */}
      <div className="relative w-full h-[2px] bg-white/[0.08] group-hover:bg-white/[0.16] transition-colors duration-300 overflow-visible">
        
        {/* Animated Traveling Golden Beam (Pauses on Hover) */}
        <div
          className="absolute inset-y-0 w-64 bg-gradient-to-r from-transparent via-[#FFF2D6] via-[#D8B263] to-transparent animate-golden-travel shadow-[0_0_16px_rgba(216,178,99,0.9)] pointer-events-none"
          style={{
            animationPlayState: isHovered ? 'paused' : 'running',
            opacity: isHovered ? 0.35 : 1,
            transition: 'opacity 0.3s ease',
          }}
        />

        {/* Interactive Cursor Bead & Luminous Tracker */}
        <AnimatePresence>
          {isHovered && (
            <motion.div
              initial={{ scale: 0, opacity: 0 }}
              animate={{ scale: 1, opacity: 1 }}
              exit={{ scale: 0, opacity: 0 }}
              transition={{ duration: 0.18 }}
              className="absolute top-1/2 -translate-y-1/2 pointer-events-none z-20"
              style={{ left: `${cursorPercent}%` }}
            >
              {/* Outer soft glow ring */}
              <div className="absolute top-1/2 left-1/2 -translate-x-1/2 -translate-y-1/2 w-8 h-8 rounded-full bg-[#D8B263]/30 blur-sm animate-ping" />
              {/* Core golden pearl */}
              <div className="w-3.5 h-3.5 -ml-[7px] rounded-full bg-[#FFF5DC] border-2 border-[#D8B263] shadow-[0_0_16px_#D8B263]" />
            </motion.div>
          )}
        </AnimatePresence>
      </div>

      {/* Floating Watch Information & Descriptive Preview Card */}
      <AnimatePresence>
        {isHovered && (
          <motion.div
            initial={{ 
              opacity: 0, 
              y: placement === 'above' ? 10 : -10, 
              scale: 0.96 
            }}
            animate={{ 
              opacity: 1, 
              y: 0, 
              scale: 1 
            }}
            exit={{ 
              opacity: 0, 
              y: placement === 'above' ? 8 : -8, 
              scale: 0.96 
            }}
            transition={{ duration: 0.22, ease: [0.16, 1, 0.3, 1] }}
            className="absolute z-40 pointer-events-none w-80 sm:w-96"
            style={{
              left: `${clampedPopupPercent}%`,
              transform: 'translateX(-50%)',
              [placement === 'above' ? 'bottom' : 'top']: 'calc(100% - 2px)',
            }}
          >
            <div className="bg-[#0D0D12]/95 backdrop-blur-xl border border-[#D8B263]/50 rounded-xs p-3.5 shadow-[0_20px_45px_rgba(0,0,0,0.95)] flex items-center gap-3.5 relative overflow-hidden">
              {/* Subtle radiant sheen */}
              <div className="absolute -top-10 -right-10 w-28 h-28 bg-[#D8B263]/15 rounded-full blur-2xl pointer-events-none" />

              {/* Watch Thumbnail Visual */}
              {watchInfo.image && (
                <div className="w-16 h-16 sm:w-18 sm:h-18 bg-black/60 border border-white/10 rounded-xs shrink-0 flex items-center justify-center p-1.5 overflow-hidden">
                  <img
                    src={watchInfo.image}
                    alt={watchInfo.name}
                    className="w-full h-full object-contain filter drop-shadow-[0_4px_10px_rgba(0,0,0,0.9)]"
                  />
                </div>
              )}

              {/* Watch Details */}
              <div className="flex-1 min-w-0">
                <div className="flex items-center justify-between text-[9px] font-mono mb-1">
                  <span className="text-[#D8B263] uppercase tracking-wider font-semibold truncate">
                    {watchInfo.tag || 'Haute Horlogerie Spec'}
                  </span>
                  <span className="text-zinc-500 font-mono shrink-0 ml-2">
                    {watchInfo.reference}
                  </span>
                </div>

                <h4 className="font-serif-luxury text-xs sm:text-sm font-semibold text-white tracking-wide truncate mb-1">
                  {watchInfo.name}
                </h4>

                {watchInfo.calibre && (
                  <div className="text-[10px] text-zinc-300 font-mono truncate mb-1">
                    {watchInfo.calibre}
                  </div>
                )}

                <p className="text-[10px] text-zinc-400 font-sans-modern leading-tight line-clamp-1">
                  {watchInfo.specs}
                </p>

                <div className="mt-1.5 flex items-center gap-1 text-[8.5px] font-mono text-[#D8B263]/80">
                  <Sparkles className="w-2.5 h-2.5" />
                  <span>Interactive Line · Beam Paused on Cursor</span>
                </div>
              </div>
            </div>

            {/* Small Pointer Notch */}
            <div 
              className={`w-2.5 h-2.5 bg-[#0D0D12] border-r border-b border-[#D8B263]/50 absolute left-1/2 -translate-x-1/2 rotate-45 ${
                placement === 'above' ? '-bottom-[6px]' : '-top-[6px] rotate-[-135deg]'
              }`} 
            />
          </motion.div>
        )}
      </AnimatePresence>
    </motion.div>
  );
};
